import React from 'react';
import { X, Star, Sparkles, Sliders, Layers, ShoppingCart, ShieldCheck } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';

interface ProductDetailModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function ProductDetailModal({ product, onClose, onAddToCart }: ProductDetailModalProps) {
  // Prevent click out close propagation
  const handleModalClick = (e: React.MouseEvent) => {
    e.stopPropagation();
  };

  return (
    <div
      id="quickview-backdrop"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-navy-deep/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
    >
      <motion.div
        id="quickview-dialog"
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ type: 'spring', duration: 0.4 }}
        onClick={handleModalClick}
        className="bg-navy-dark border border-gold-premium/20 max-w-4xl w-full rounded-2xl overflow-hidden shadow-2xl relative"
      >
        {/* Close Button */}
        <button
          id="close-quickview-modal"
          onClick={onClose}
          className="absolute top-4 right-4 z-10 p-2 bg-black/40 hover:bg-gold-premium hover:text-navy-dark text-white rounded-full transition-all focus:outline-none cursor-pointer"
          aria-label="Close modal"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Glass Studio Stage for Perfume image */}
          <div className="bg-navy-deep/60 p-6 flex items-center justify-center relative min-h-[300px]">
            {/* Background luxury gradient glowing */}
            <div className="absolute inset-0 bg-radial-gradient from-gold-premium/5 via-transparent to-transparent opacity-50" />
            
            <img
              id="quickview-hero-img"
              src={product.image}
              alt={product.name}
              className="max-h-[350px] object-contain rounded-2xl relative z-10 drop-shadow-[0_15px_30px_rgba(212,175,55,0.15)]"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Full Detailed Attributes Panel */}
          <div className="p-6 md:p-8 flex flex-col justify-between">
            <div>
              {/* Category, Rating, Volume */}
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] uppercase tracking-widest bg-gold-premium/15 border border-gold-premium/30 text-gold-premium px-2.5 py-1 rounded-full font-semibold">
                  {product.category} Collection
                </span>
                <span className="text-xs text-grey-light/70 font-mono">
                  {product.volume}
                </span>
              </div>

              {/* Title & Tagline */}
              <h2
                id="quickview-title"
                className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-wide mb-1"
              >
                {product.name}
              </h2>
              <p className="text-sm italic font-serif text-gold-premium mb-4">
                "{product.tagline}"
              </p>

              {/* Star Rating & Intensity indicator */}
              <div className="flex flex-wrap items-center gap-4 mb-6 border-b border-white/5 pb-4">
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(product.rating)
                          ? 'text-gold-premium fill-gold-premium'
                          : 'text-grey-light/30'
                      }`}
                    />
                  ))}
                  <span className="text-xs font-bold text-white ml-1">{product.rating}</span>
                </div>
                <div className="h-4 w-[1px] bg-white/10 hidden sm:block" />
                <div className="flex items-center space-x-1 text-xs">
                  <Sliders className="h-4 w-4 text-gold-premium" />
                  <span className="text-grey-light/80">Sillage Intensity:</span>
                  <span className="font-semibold text-white uppercase tracking-wider text-[11px] ml-1">
                    {product.intensity}
                  </span>
                </div>
              </div>

              {/* Complete narrative */}
              <div className="mb-6">
                <h4 className="text-xs uppercase tracking-widest text-gold-premium font-semibold mb-2">
                  The Fragrance Narrative
                </h4>
                <p id="quickview-narrative" className="text-xs sm:text-sm text-grey-light leading-relaxed">
                  {product.fullDescription}
                </p>
              </div>

              {/* Fragrance pyramid with visual stacking */}
              <div className="mb-6 bg-grey-dark/30 rounded-xl p-4 border border-white/5">
                <h4 className="text-xs uppercase tracking-widest text-gold-premium font-semibold mb-3 flex items-center space-x-1">
                  <Layers className="h-3.5 w-3.5" />
                  <span>The Olfactory Pyramid</span>
                </h4>
                <div className="space-y-2.5 text-xs">
                  <div className="flex py-1 border-b border-white/5">
                    <span className="w-20 uppercase tracking-wider text-grey-light/50 font-mono font-medium">Top Notes:</span>
                    <span className="flex-1 text-white">{product.notes.top}</span>
                  </div>
                  <div className="flex py-1 border-b border-white/5">
                    <span className="w-20 uppercase tracking-wider text-grey-light/50 font-mono font-medium">Heart:</span>
                    <span className="flex-1 text-white italic">{product.notes.heart}</span>
                  </div>
                  <div className="flex py-1">
                    <span className="w-20 uppercase tracking-wider text-grey-light/50 font-mono font-medium">Base:</span>
                    <span className="flex-1 text-white">{product.notes.base}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quality Seal & Call to Action */}
            <div className="border-t border-white/5 pt-5 flex items-center justify-between">
              <div className="flex flex-col">
                <span className="text-[10px] uppercase tracking-wider text-grey-light/50 font-mono">
                  Royal Offer Price
                </span>
                <span id="quickview-price" className="text-2xl font-mono font-bold text-white">
                  ₹{product.price.toLocaleString('en-IN')}
                </span>
                <span className="text-[10px] text-emerald-400 mt-1 flex items-center">
                  <ShieldCheck className="h-3 w-3 mr-1" /> Free premium secure shipping
                </span>
              </div>

              <button
                id="quickview-add-to-cart"
                onClick={() => {
                  onAddToCart(product);
                  onClose();
                }}
                className="flex items-center space-x-2 bg-gold-premium text-navy-dark font-sans text-xs uppercase tracking-widest font-bold px-6 py-3.5 rounded-lg border border-gold-premium hover:bg-transparent hover:text-gold-premium transition-all duration-300 transform active:scale-95 cursor-pointer shadow-lg shadow-gold-premium/20"
              >
                <ShoppingCart className="h-4 w-4" />
                <span>Add to Cart</span>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
