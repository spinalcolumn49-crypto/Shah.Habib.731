import { X, Plus, Minus, Trash2, ShoppingBag, Lock, Gift } from 'lucide-react';
import { CartItem } from '../types';
import { motion } from 'motion/react';

interface CartSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: () => void;
}

export default function CartSidebar({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout
}: CartSidebarProps) {
  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const deliveryCharges = 0; // Free for luxury clients
  const total = subtotal + deliveryCharges;

  if (!isOpen) return null;

  return (
    <div
      id="cart-drawer-backdrop"
      onClick={onClose}
      className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex justify-end"
    >
      <motion.div
        id="cart-drawer-panel"
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'tween', duration: 0.35 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md bg-navy-dark border-l border-gold-premium/20 h-full flex flex-col justify-between shadow-2xl relative z-50"
      >
        {/* Cart Header */}
        <div className="p-5 border-b border-white/5 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <ShoppingBag className="h-5 w-5 text-gold-premium" />
            <h2 className="text-lg font-serif font-semibold text-white tracking-widest uppercase">
              Your Fragrances ({cartItems.reduce((acc, item) => acc + item.quantity, 0)})
            </h2>
          </div>
          <button
            id="close-cart-sidebar"
            onClick={onClose}
            className="p-2 hover:bg-white/10 rounded-full transition-colors text-grey-light hover:text-white cursor-pointer"
            aria-label="Close cart"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Cart Item Stack list */}
        <div id="cart-item-list" className="flex-1 overflow-y-auto p-5 space-y-4">
          {cartItems.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-72 text-center space-y-4">
              <div className="p-4 bg-white/5 rounded-full border border-gold-premium/10 text-gold-premium">
                <ShoppingBag className="h-10 w-10 stroke-[1.5]" />
              </div>
              <p className="font-serif text-lg text-white font-medium">Your sensory tray is empty.</p>
              <p className="text-xs text-grey-light max-w-xs leading-relaxed">
                Browse our imperial collection of rare Oud and Saffron formulas to add a touch of romance to your aura.
              </p>
              <button
                onClick={onClose}
                className="text-xs uppercase tracking-widest text-gold-premium border-b border-gold-premium pb-0.5 hover:text-white hover:border-white transition-all focus:outline-none"
              >
                Start Exploring
              </button>
            </div>
          ) : (
            cartItems.map((item) => (
              <div
                key={item.product.id}
                id={`cart-item-card-${item.product.id}`}
                className="flex space-x-3.5 bg-grey-dark/30 rounded-xl p-3 border border-white/5 hover:border-gold-premium/20 transition-all group"
              >
                {/* Thumb */}
                <div className="w-20 h-20 bg-navy-deep/60 rounded-lg p-1 flex items-center justify-center overflow-hidden flex-shrink-0">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-full h-full object-cover rounded-md group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                </div>

                {/* Info and adjustments */}
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-sm font-serif font-bold text-white leading-tight">
                        {item.product.name}
                      </h4>
                      <p className="text-[10px] text-gold-premium italic font-serif">
                        {item.product.volume}
                      </p>
                    </div>

                    <button
                      id={`remove-cart-item-${item.product.id}`}
                      onClick={() => onRemoveItem(item.product.id)}
                      className="p-1 hover:text-red-400 text-grey-light/50 transition-colors cursor-pointer"
                      title="Remove product"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between mt-2">
                    {/* Quantity Selector controls */}
                    <div className="flex items-center space-x-1 bg-navy-deep/80 border border-white/5 rounded-lg px-1 py-0.5">
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, -1)}
                        className="p-1 text-grey-light hover:text-white disabled:opacity-30 cursor-pointer"
                        disabled={item.quantity <= 1}
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="text-xs font-mono font-bold text-white px-2">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.product.id, 1)}
                        className="p-1 text-grey-light hover:text-white cursor-pointer"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>

                    <span className="text-sm font-mono font-bold text-white">
                      ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Pricing totals block */}
        {cartItems.length > 0 && (
          <div className="p-5 border-t border-white/5 bg-navy-deep/40 space-y-4">
            {/* Free Shipping incentive */}
            <div className="bg-gold-premium/5 border border-gold-premium/15 rounded-xl p-3 flex space-x-3 items-start">
              <Gift className="h-5 w-5 text-gold-premium flex-shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-white">Imperial Complimentary Box</p>
                <p className="text-grey-light/80 mt-0.5">
                  Your order is qualified for our Signature leather cases, scented card inserts, and free insured shipping.
                </p>
              </div>
            </div>

            {/* Calculations */}
            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-grey-light">
                <span>Subtotal</span>
                <span className="font-mono">₹{subtotal.toLocaleString('en-IN')}</span>
              </div>
              <div className="flex justify-between text-grey-light">
                <span>VIP Insured Delivery</span>
                <span className="text-gold-premium uppercase font-medium">Free</span>
              </div>
              <div className="border-t border-white/5 pt-2 flex justify-between text-sm font-semibold text-white">
                <span>Total Amount</span>
                <span id="cart-total-price" className="font-mono text-base text-gold-premium">
                  ₹{total.toLocaleString('en-IN')}
                </span>
              </div>
            </div>

            {/* Checkout CTA */}
            <button
              id="checkout-cta-btn"
              onClick={onCheckout}
              className="w-full flex items-center justify-center space-x-2 bg-gold-premium text-navy-dark font-sans text-xs uppercase tracking-widest font-bold py-4 rounded-xl border border-gold-premium hover:bg-transparent hover:text-gold-premium transition-all duration-300 shadow-xl cursor-pointer"
            >
              <Lock className="h-4 w-4" />
              <span>Secure Order Checkout</span>
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
