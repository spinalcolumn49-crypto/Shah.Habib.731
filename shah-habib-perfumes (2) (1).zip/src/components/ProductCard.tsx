import React from 'react';
import { Star, Eye, ShoppingCart } from 'lucide-react';
import { Product } from '../types';
import { motion } from 'motion/react';

interface ProductCardProps {
  key?: string;
  product: Product;
  onAddToCart: (product: Product) => void;
  onBuyNow: (product: Product) => void;
  onQuickView: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onBuyNow, onQuickView }: ProductCardProps) {
  return (
    <motion.div
      id={`product-card-${product.id}`}
      whileHover={{ y: -8 }}
      transition={{ duration: 0.3 }}
      className="bg-grey-dark/40 backdrop-blur-md rounded-2xl border border-gold-premium/15 overflow-hidden group flex flex-col h-full shadow-xl shadow-navy-deep/20 transition-all hover:border-gold-premium/45 hover:shadow-gold-premium/5"
    >
      {/* Product Image Stage */}
      <div className="relative overflow-hidden aspect-square bg-navy-deep/60 flex items-center justify-center p-4">
        {/* Category Label */}
        <span
          id={`product-card-${product.id}-category`}
          className="absolute top-4 left-4 z-10 text-[9px] uppercase tracking-widest bg-gold-premium/15 border border-gold-premium/40 text-gold-premium px-2.5 py-1 rounded-full font-medium"
        >
          {product.category}
        </span>

        {/* Rating Label */}
        <div className="absolute top-4 right-4 z-10 flex items-center space-x-1 bg-black/50 backdrop-blur-md px-2 py-0.5 rounded text-[10px] text-white">
          <Star className="h-3 w-3 fill-gold-premium text-gold-premium" />
          <span className="font-semibold">{product.rating}</span>
        </div>

        {/* actual image */}
        <img
          id={`product-card-${product.id}-img`}
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover rounded-xl transition-transform duration-700 ease-out group-hover:scale-105"
          referrerPolicy="no-referrer"
        />

        {/* Hover Overlay featuring Quick View */}
        <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-3">
          <button
            id={`quick-view-btn-${product.id}`}
            onClick={() => onQuickView(product)}
            className="p-3 bg-gold-premium text-navy-dark rounded-full hover:bg-gold-light active:scale-95 transition-all shadow-md cursor-pointer"
            title="Quick View Fragrance Details"
          >
            <Eye className="h-5 w-5 font-bold" />
          </button>
        </div>
      </div>

      {/* Product Details Area */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-baseline justify-between mb-1">
            <h3
              id={`product-card-${product.id}-title`}
              className="text-lg font-serif font-semibold text-white tracking-wide group-hover:text-gold-premium transition-colors"
            >
              {product.name}
            </h3>
            <span
              id={`product-card-${product.id}-volume`}
              className="text-[10px] text-grey-light/60 font-mono"
            >
              {product.volume}
            </span>
          </div>

          <p className="text-xs text-gold-premium font-serif italic mb-2 tracking-wide font-medium">
            {product.tagline}
          </p>

          <p className="text-xs text-grey-light line-clamp-2 leading-relaxed mb-4">
            {product.description}
          </p>
        </div>

        <div>
          {/* Fragrance pyramid glimpse */}
          <div className="border-t border-white/5 pt-3 mb-4 flex flex-col space-y-1">
            <span className="text-[10px] uppercase tracking-wider text-grey-light/50 font-mono">
              Key Note: <span className="text-white font-sans text-[11px]">{product.notes.heart.split(',')[0]}</span>
            </span>
          </div>

          <div className="flex flex-col space-y-3.5 mt-auto pt-3.5 border-t border-white/5">
            <div className="flex items-baseline justify-between">
              <span className="text-[10px] uppercase tracking-wider text-grey-light/55">
                Grand Price
              </span>
              <span
                id={`product-card-${product.id}-price`}
                className="text-lg font-mono font-bold text-white group-hover:text-gold-premium transition-colors"
              >
                ₹{product.price.toLocaleString('en-IN')}
              </span>
            </div>

            {/* Action buttons grid */}
            <div className="grid grid-cols-2 gap-2">
              <button
                id={`add-to-cart-btn-${product.id}`}
                onClick={() => onAddToCart(product)}
                className="flex items-center justify-center space-x-1 bg-transparent text-white border border-white/10 hover:border-gold-premium hover:text-gold-premium font-sans text-[10px] uppercase tracking-wider font-semibold py-2.5 rounded-lg transition-all duration-200 transform active:scale-95 cursor-pointer"
              >
                <ShoppingCart className="h-3 w-3" />
                <span>+ Cart</span>
              </button>

              <button
                id={`buy-now-btn-${product.id}`}
                onClick={() => onBuyNow(product)}
                className="flex items-center justify-center space-x-1 border border-gold-premium bg-gold-premium text-navy-dark font-sans text-[10px] uppercase tracking-wider font-bold py-2.5 rounded-lg hover:bg-transparent hover:text-gold-premium transition-all duration-200 transform active:scale-95 cursor-pointer shadow-md shadow-gold-premium/5"
              >
                <span>Buy Now</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
