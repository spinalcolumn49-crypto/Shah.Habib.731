import React, { useState, useEffect } from 'react';
import { ShoppingBag, Menu, X, Crown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface NavbarProps {
  cartCount: number;
  onCartClick: () => void;
  activeSection: string;
}

export default function Navbar({ cartCount, onCartClick, activeSection }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 30) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', href: '#home' },
    { label: 'Shop', href: '#shop' },
    { label: 'About', href: '#about' },
    { label: 'Our Process', href: '#process' },
    { label: 'Reviews', href: '#reviews' },
    { label: 'Contact', href: '#contact' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offsetTop = (targetElement as HTMLElement).offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth',
      });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav
      id="main-nav"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-500 ${
        isScrolled
          ? 'bg-navy-dark/95 backdrop-blur-md py-4 border-b border-gold-premium/20 shadow-lg shadow-navy-deep/40'
          : 'bg-transparent py-6 border-b border-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            id="brand-logo-link"
            href="#home"
            onClick={(e) => handleNavClick(e, '#home')}
            className="flex items-center space-x-2 group focus:outline-none"
          >
            <Crown className="h-7 w-7 text-gold-premium transition-transform duration-500 group-hover:rotate-12" />
            <div className="flex flex-col">
              <span className="text-xl sm:text-2xl font-serif font-semibold tracking-widest text-white leading-none">
                SHAH HABIB
              </span>
              <span className="text-[9px] tracking-[0.25em] text-gold-premium uppercase leading-none mt-1">
                Luxury Fragrances
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links */}
          <div id="desktop-menu" className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={(e) => handleNavClick(e, item.href)}
                className={`text-xs uppercase tracking-widest transition-all duration-300 hover:text-gold-premium focus:outline-none relative py-1 ${
                  activeSection === item.href.slice(1)
                    ? 'text-gold-premium font-medium'
                    : 'text-grey-light hover:text-white'
                }`}
              >
                {item.label}
                {activeSection === item.href.slice(1) && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 w-full h-[1px] bg-gold-premium"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </a>
            ))}
          </div>

          {/* Action Buttons (Cart, Mobile Menu Toggle) */}
          <div className="flex items-center space-x-4">
            {/* Shopping Cart Button */}
            <button
              id="cart-panel-trigger"
              onClick={onCartClick}
              className="relative p-2 text-grey-light hover:text-gold-premium transition-colors focus:outline-none group"
              aria-label="Shopping Cart"
            >
              <ShoppingBag className="h-6 w-6 transition-transform group-hover:scale-110" />
              {cartCount > 0 && (
                <span
                  id="cart-badge-count"
                  className="absolute -top-1 -right-1 bg-gold-premium text-navy-dark text-[10px] font-bold w-5 h-5 rounded-full flex items-center justify-center animate-pulse"
                >
                  {cartCount}
                </span>
              )}
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 text-grey-light hover:text-white transition-colors focus:outline-none"
              aria-label="Toggle Mobile Menu"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            id="mobile-drawer-portal"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden bg-navy-deep border-b border-gold-premium/10 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-4">
              {navItems.map((item) => (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={(e) => handleNavClick(e, item.href)}
                  className={`block px-3 py-2 rounded text-sm uppercase tracking-widest hover:bg-grey-medium/30 transition-all ${
                    activeSection === item.href.slice(1)
                      ? 'text-gold-premium font-medium text-right border-r-2 border-gold-premium pr-2'
                      : 'text-grey-light hover:text-white'
                  }`}
                >
                  {item.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
