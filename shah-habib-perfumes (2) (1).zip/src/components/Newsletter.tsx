import React, { useState } from 'react';
import { Mail, ArrowRight, ShieldCheck, Phone, MapPin, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Newsletter() {
  const [email, setEmail] = useState('');
  const [isSubscribed, setIsSubscribed] = useState(false);
  const [isError, setIsError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !email.includes('@')) {
      setIsError(true);
      return;
    }

    setIsError(false);
    setIsSubscribed(true);
    setEmail('');
  };

  return (
    <section id="contact" className="py-20 sm:py-28 bg-navy-deep relative overflow-hidden">
      {/* Background glowing rings */}
      <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-gold-premium/5 blur-3xl" />
      <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-gold-premium/5 blur-3xl" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          
          {/* Brand Promise & Mock details */}
          <div className="space-y-6 sm:space-y-8">
            <div className="space-y-4">
              <span className="text-xs uppercase tracking-widest text-gold-premium font-semibold flex items-center space-x-1">
                <Sparkles className="h-4 w-4" />
                <span>The Private Circle</span>
              </span>
              <h2 className="text-3xl sm:text-4xl font-serif font-semibold text-white tracking-wide leading-tight">
                Embrace the Legacy.<br className="hidden sm:inline" /> Stay Mystically Engaged.
              </h2>
              <p className="text-grey-light text-sm sm:text-base leading-relaxed max-w-xl">
                Register with Shah Habib’s private newsletter. Receive priority allocations on rare harvests of agarwood and exclusive pre-launch updates on future limited batch releases of luxury perfumery.
              </p>
            </div>

            {/* Corporate Address and Support Coordinates */}
            <div className="space-y-4 border-t border-white/5 pt-6 sm:pt-8">
              <div className="flex items-center space-x-3 text-sm">
                <Mail className="h-5 w-5 text-gold-premium flex-shrink-0" />
                <div>
                  <span className="block text-[10px] uppercase tracking-widest text-grey-light/45 font-mono">Sensory Support</span>
                  <a href="mailto:support@shahhabib.com" className="text-white hover:text-gold-premium transition-colors">
                    support@shahhabib.com
                  </a>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-sm">
                <Phone className="h-5 w-5 text-gold-premium flex-shrink-0" />
                <div>
                  <span className="block text-[10px] uppercase tracking-widest text-grey-light/45 font-mono">Bespoke Concierge</span>
                  <span className="text-white">+91 98765 43210</span>
                </div>
              </div>

              <div className="flex items-center space-x-3 text-sm">
                <MapPin className="h-5 w-5 text-gold-premium flex-shrink-0" />
                <div>
                  <span className="block text-[10px] uppercase tracking-widest text-grey-light/45 font-mono">The Perfumery Atelier</span>
                  <span className="text-white">Shah Habib Craft Mansion, New Delhi, India</span>
                </div>
              </div>
            </div>
          </div>

          {/* Form Widget card */}
          <div className="bg-grey-dark/45 backdrop-blur-md rounded-2xl border border-gold-premium/15 p-6 sm:p-10 relative">
            <div className="absolute top-0 right-0 transform translate-x-2 -translate-y-2 text-[10px] uppercase bg-gold-premium text-navy-dark font-extrabold px-3 py-1 rounded tracking-widest">
              INVITE ONLY
            </div>

            <h3 className="text-xl font-serif font-bold text-white tracking-wide mb-2">
              Request Your Affiliation
            </h3>
            <p className="text-xs text-grey-light/80 mb-6 leading-relaxed">
              We respect your confidentiality. Our messages are selective containing details that matter only to the refined collector.
            </p>

            <AnimatePresence mode="wait">
              {!isSubscribed ? (
                <motion.form
                  key="subscribe-form"
                  onSubmit={handleSubmit}
                  className="space-y-4"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                >
                  <div className="relative">
                    <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-grey-light/40" />
                    <input
                      id="newsletter-email-input"
                      type="email"
                      value={email}
                      onChange={(e) => {
                        setEmail(e.target.value);
                        if (isError) setIsError(false);
                      }}
                      placeholder="Enter your email address"
                      className={`w-full bg-navy-deep border ${
                        isError ? 'border-red-500' : 'border-gold-premium/20 focus:border-gold-premium'
                      } text-white pl-12 pr-4 py-3.5 rounded-xl text-sm focus:outline-none focus:ring-1 focus:ring-gold-premium transition-all font-sans`}
                    />
                  </div>

                  {isError && (
                    <p className="text-xs text-red-400 font-medium">
                      Please submit a valid email coordinate format.
                    </p>
                  )}

                  <button
                    id="newsletter-submit-btn"
                    type="submit"
                    className="w-full flex items-center justify-center space-x-2 bg-gold-premium text-navy-dark font-sans text-xs uppercase tracking-widest font-bold py-4 rounded-xl border border-gold-premium hover:bg-transparent hover:text-gold-premium transition-all duration-300 transform active:scale-95 cursor-pointer shadow-lg shadow-gold-premium/10"
                  >
                    <span>Send Affirmation Code</span>
                    <ArrowRight className="h-4 w-4" />
                  </button>

                  <div className="pt-2 flex items-center space-x-2 text-[10px] text-grey-light/50">
                    <ShieldCheck className="h-4 w-4 text-gold-premium" />
                    <span>Your personal coordinates are shielded by enterprise-grade SSL guard.</span>
                  </div>
                </motion.form>
              ) : (
                <motion.div
                  key="success-form"
                  className="py-8 text-center space-y-4"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200 }}
                >
                  <div className="mx-auto w-12 h-12 bg-gold-premium/15 border border-gold-premium text-gold-premium rounded-full flex items-center justify-center">
                    <ShieldCheck className="h-6 w-6" />
                  </div>
                  <h4 className="font-serif font-semibold text-lg text-white">Affiliation Request Approved</h4>
                  <p className="text-xs text-grey-light max-w-sm mx-auto leading-relaxed">
                    Welcome to the Court of Shah Habib. A formal greeting with details has been sealed and dispatched to your mailbox.
                  </p>
                  <button
                    id="newsletter-reset-btn"
                    onClick={() => setIsSubscribed(false)}
                    className="text-[10px] uppercase tracking-widest text-gold-premium border-b border-gold-premium pb-0.5 hover:text-white hover:border-white transition-all cursor-pointer"
                  >
                    Register another address
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}
