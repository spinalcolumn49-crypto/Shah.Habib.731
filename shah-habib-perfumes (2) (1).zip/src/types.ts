export interface Product {
  id: string;
  name: string;
  tagline: string;
  description: string;
  fullDescription: string;
  price: number; // in INR (currency: ₹)
  image: string;
  category: 'Woody' | 'Sweet' | 'Spicy' | 'Fresh';
  notes: {
    top: string;
    heart: string;
    base: string;
  };
  volume: string; // e.g., "100ml / 3.4 FL.OZ."
  intensity: 'Intense' | 'Medium' | 'Subtle';
  rating: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface Review {
  id: string;
  name: string;
  rating: number;
  comment: string;
  date: string;
  verified: boolean;
}
