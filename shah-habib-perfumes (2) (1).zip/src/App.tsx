import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Award,
  Truck,
  Heart,
  ChevronRight,
  ShieldCheck,
  Package,
  CheckCircle2,
  Undo2,
  Dribbble,
  Facebook,
  Instagram,
  Compass,
  Hourglass,
  ArrowRight,
  Star,
  X
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// Data repositories and structural types
import { PRODUCTS, HERO_BANNER_IMAGE, REVIEWS } from './data';
import { Product, CartItem } from './types';

// App modular sub-components
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import CartSidebar from './components/CartSidebar';
import Newsletter from './components/Newsletter';

export default function App() {
  // 1. Persistent Storage states
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const persisted = localStorage.getItem('shah_habib_cart');
      return persisted ? JSON.parse(persisted) : [];
    } catch {
      return [];
    }
  });

  // 2. Active Screen visual states
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [activeCategory, setActiveCategory] = useState<'All' | 'Woody' | 'Sweet' | 'Spicy' | 'Fresh'>('All');
  
  // 3. Matcher Quiz State
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [quizAnswers, setQuizAnswers] = useState({ occasion: '', notePreference: '' });
  const [matchedProduct, setMatchedProduct] = useState<Product | null>(null);

  // 4. Checkout confirmation state
  const [lastCompletedOrder, setLastCompletedOrder] = useState<{
    orderId: string;
    items: CartItem[];
    amount: number;
  } | null>(null);

  // Synchronize cart with client-side localStorage
  useEffect(() => {
    localStorage.setItem('shah_habib_cart', JSON.stringify(cart));
  }, [cart]);

  // Track scroll position to update Navbar highlighter active links
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'shop', 'about', 'process', 'reviews', 'contact'];
      const scrollPosition = window.scrollY + 150;

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.product.id === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prevCart, { product, quantity: 1 }];
    });
    // Open cart sidebar on addition for premium direct response feel
    setIsCartOpen(true);
  };

  const handleBuyNow = (product: Product) => {
    // Standard direct one-click checkout
    const orderId = 'SH-' + Math.floor(100000 + Math.random() * 900000);
    setLastCompletedOrder({
      orderId,
      items: [{ product, quantity: 1 }],
      amount: product.price,
    });
    // Clear cart for a fresh experience
    setCart([]);
    setIsCartOpen(false);
    
    // Standard requested alert statement
    alert('Order placed successfully! Thank you for shopping at Shah Habib.');
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCart((prevCart) =>
      prevCart
        .map((item) => {
          if (item.product.id === productId) {
            const nextQty = item.quantity + delta;
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.product.id !== productId));
  };

  const handleCheckoutSubmit = () => {
    if (cart.length === 0) return;

    const orderId = 'SH-' + Math.floor(100000 + Math.random() * 900000);
    const subtotal = cart.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

    setLastCompletedOrder({
      orderId,
      items: cart,
      amount: subtotal,
    });

    // Clear cart memory
    setCart([]);
    setIsCartOpen(false);

    // Standard requested callback statement
    alert('Order placed successfully! Thank you for shopping at Shah Habib.');
  };

  // Scent quiz matcher logic
  const handleScentQuiz = (field: 'occasion' | 'notePreference', value: string) => {
    const nextAnswers = { ...quizAnswers, [field]: value };
    setQuizAnswers(nextAnswers);

    if (nextAnswers.occasion && nextAnswers.notePreference) {
      // Find matches based on traits
      let matched = PRODUCTS[0]; // fallback
      if (nextAnswers.notePreference === 'aquatic' || nextAnswers.occasion === 'day') {
        matched = PRODUCTS.find((p) => p.category === 'Fresh') || PRODUCTS[3];
      } else if (nextAnswers.notePreference === 'oud') {
        matched = PRODUCTS.find((p) => p.category === 'Woody') || PRODUCTS[0];
      } else if (nextAnswers.notePreference === 'leather') {
        matched = PRODUCTS.find((p) => p.category === 'Spicy') || PRODUCTS[2];
      } else if (nextAnswers.notePreference === 'amber') {
        matched = PRODUCTS.find((p) => p.category === 'Sweet') || PRODUCTS[1];
      }
      setMatchedProduct(matched);
    }
  };

  const resetScentQuiz = () => {
    setQuizAnswers({ occasion: '', notePreference: '' });
    setMatchedProduct(null);
  };

  // Product Filter
  const filteredProducts = activeCategory === 'All'
    ? PRODUCTS
    : PRODUCTS.filter((p) => p.category === activeCategory);

  return (
    <div className="relative min-h-screen bg-navy-dark text-white font-sans selection:bg-gold-premium selection:text-navy-dark">
      {/* 1. Navbar */}
      <Navbar
        cartCount={cart.reduce((acc, item) => acc + item.quantity, 0)}
        onCartClick={() => setIsCartOpen(true)}
        activeSection={activeSection}
      />

      {/* 2. Hero Section */}
      <section
        id="home"
        className="relative min-h-screen flex items-center justify-center pt-24 overflow-hidden"
      >
        {/* Cinematic Backdrop Image with Luxury Gradients */}
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-t from-navy-dark via-navy-dark/75 to-navy-dark/25 z-10" />
          <div className="absolute inset-0 bg-gradient-to-r from-navy-dark via-transparent to-navy-dark z-10" />
          <img
            src={HERO_BANNER_IMAGE}
            alt="Shah Habib Perfume Background Banner"
            className="w-full h-full object-cover scale-105 filter brightness-75 select-none"
            referrerPolicy="no-referrer"
          />
        </div>

        {/* Hero Copy Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-20 text-center space-y-8 sm:space-y-10 py-12">
          {/* Brand Seal Emblem */}
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8 }}
            className="inline-flex items-center space-x-2 bg-gold-premium/10 border border-gold-premium/35 rounded-full px-5 py-2"
          >
            <Sparkles className="h-4 w-4 text-gold-premium animate-pulse" />
            <span className="text-[10px] uppercase tracking-[0.3em] text-gold-light font-semibold">
              The Imperial Royal Scented Crest
            </span>
          </motion.div>

          <div className="space-y-4 max-w-3xl mx-auto">
            <h1
              id="hero-tagline"
              className="text-4xl sm:text-6xl md:text-7xl font-serif font-semibold text-white tracking-wider leading-tight sm:leading-none"
            >
              Shah Habib
              <span className="block text-2xl sm:text-4xl md:text-5xl mt-3 sm:mt-5 font-serif font-normal italic text-gold-premium">
                The Essence of Royalty
              </span>
            </h1>

            <p className="text-sm sm:text-lg text-grey-light/90 font-light max-w-xl mx-auto leading-relaxed pt-2">
              Discover grand, handcrafted luxury fragrances curated exclusively for the modern connoisseur of elite life.
            </p>
          </div>

          {/* Interactive CTAs */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <a
              id="hero-cta-shop"
              href="#shop"
              onClick={(e) => {
                e.preventDefault();
                const shopSec = document.getElementById('shop');
                if (shopSec) window.scrollTo({ top: shopSec.offsetTop - 82, behavior: 'smooth' });
              }}
              className="w-full sm:w-auto bg-gold-premium text-navy-dark font-sans text-xs uppercase tracking-widest font-bold px-8 py-4 rounded-xl border border-gold-premium hover:bg-transparent hover:text-gold-premium transition-all duration-300 transform active:scale-95 text-center cursor-pointer shadow-xl shadow-gold-premium/20"
            >
              Shop the Collection
            </a>

            <button
              id="quiz-opening-trigger"
              onClick={() => setIsQuizOpen(true)}
              className="w-full sm:w-auto bg-transparent text-white font-sans text-xs uppercase tracking-widest font-semibold px-8 py-4 rounded-xl border border-white/20 hover:border-gold-premium hover:text-gold-premium transition-all duration-300 backdrop-blur-sm cursor-pointer"
            >
              Match Signature Scent
            </button>
          </div>

          {/* Brand highlights footer bar */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-4 max-w-4xl mx-auto pt-16 sm:pt-24 border-t border-white/5">
            <div className="flex flex-col items-center space-y-1">
              <Award className="h-6 w-6 text-gold-premium" />
              <span className="text-xs font-semibold text-white">Rare Ingredients</span>
              <span className="text-[10px] text-grey-light/60">Agarwood & Saffron</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <Hourglass className="h-6 w-6 text-gold-premium" />
              <span className="text-xs font-semibold text-white">12+ Hours Longevity</span>
              <span className="text-[10px] text-grey-light/60">Extrait de Parfum</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <Truck className="h-6 w-6 text-gold-premium" />
              <span className="text-xs font-semibold text-white">VIP Secure Express</span>
              <span className="text-[10px] text-grey-light/60">Complimentary delivery</span>
            </div>
            <div className="flex flex-col items-center space-y-1">
              <ShieldCheck className="h-6 w-6 text-gold-premium" />
              <span className="text-xs font-semibold text-white">Authentic Gurantee</span>
              <span className="text-[10px] text-grey-light/60">100% genuine blend</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Featured Products Grid Section */}
      <section id="shop" className="py-24 bg-navy-dark relative">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-gold-premium/20 to-transparent" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center space-y-4 mb-16">
            <span className="text-xs uppercase tracking-[0.3em] text-gold-premium font-semibold">
              The Sovereign Collection
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-semibold text-white tracking-wide">
              Featured Fragrances
            </h2>
            <div className="w-16 h-[1.5px] bg-gold-premium mx-auto my-3" />
            <p className="text-xs sm:text-sm text-grey-light/80 max-w-xl mx-auto leading-relaxed">
              Explore meticulously tailored formulas featuring pure agarwood notes, sweet amber matrices, and spicy leather alignments.
            </p>

            {/* Collection Tabs/Filters */}
            <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
              {(['All', 'Woody', 'Sweet', 'Spicy', 'Fresh'] as const).map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`text-[10px] uppercase tracking-widest px-5 py-2.5 rounded-full border transition-all duration-300 font-medium cursor-pointer ${
                    activeCategory === category
                      ? 'bg-gold-premium text-navy-dark border-gold-premium font-bold'
                      : 'bg-transparent text-grey-light border-white/10 hover:border-gold-premium/55 hover:text-white'
                  }`}
                >
                  {category} {category !== 'All' ? 'Notes' : ''}
                </button>
              ))}
            </div>
          </div>

          {/* Product cards Grid cascade */}
          <div id="fragrances-grid" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredProducts.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                onAddToCart={handleAddToCart}
                onBuyNow={handleBuyNow}
                onQuickView={(prod) => setSelectedProduct(prod)}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 4. About Us Master Narrative Section */}
      <section id="about" className="py-24 sm:py-32 bg-grey-dark/20 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-gold-premium/15 to-transparent" />
        {/* Ambient background decoration */}
        <div className="absolute right-0 top-1/2 -translate-y-1/2 w-96 h-96 rounded-full bg-gold-premium/5 blur-3xl" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            
            {/* Visual Narrative Side */}
            <div className="lg:col-span-5 relative">
              <div className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-gold-premium/30 to-transparent blur-lg opacity-40" />
              <div className="relative bg-navy-deep p-4 rounded-2xl border border-gold-premium/20">
                <img
                  src={PRODUCTS[0].image}
                  alt="Crafting Perfume Bottle Atelier"
                  className="w-full h-auto rounded-xl object-cover flip-horizontal select-none max-h-[460px]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Micro info tag absolute positioned */}
                <div className="absolute bottom-10 left-10 right-10 bg-navy-dark/90 backdrop-blur-md p-4 rounded-xl border border-gold-premium/20 flex items-center justify-between">
                  <div>
                    <span className="block text-[8px] uppercase tracking-widest text-[#D4AF37]">The Royal Origin</span>
                    <span className="text-xs font-serif font-semibold text-white tracking-wide">Handcrafted in Imperial Glass</span>
                  </div>
                  <CrownBadge />
                </div>
              </div>
            </div>

            {/* Typography Story Narrative description */}
            <div className="lg:col-span-7 space-y-6 sm:space-y-8">
              <div className="space-y-4">
                <span className="text-xs uppercase tracking-[0.25em] text-gold-premium font-semibold block">
                  The House of Shah Habib
                </span>
                <h2 className="text-3xl sm:text-5xl font-serif font-bold text-white tracking-wide leading-tight">
                  Our Legacy of Rare Artistry
                </h2>
                <div className="w-16 h-1 bg-gold-premium" />
              </div>

              <div className="space-y-4 text-sm text-grey-light font-light leading-relaxed">
                <p>
                  Shah Habib perfumes are handcrafted using rare, ethically harvested ingredients sourced from sacred estates around the world. We combine ancient Eastern distillation craft with French olfactory expertise to develop formulations worthy of royal status.
                </p>
                <p>
                  Each precious bottle tells an elaborate story of elegance, passion, and timeless artistry. From pure Assam agarwood oil to deep Italian citrus trees and Moroccan rose petals, our concentration is kept at an unparalleled <strong>Extrait de Parfum (30%)</strong> level to assure outstanding projection and legendary sillage.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-6 pt-4 border-t border-white/5">
                <div>
                  <span className="block font-serif text-3xl font-semibold text-gold-premium">30%</span>
                  <span className="text-xs text-grey-light/70 uppercase tracking-wider">Fragrance Concentration</span>
                </div>
                <div>
                  <span className="block font-serif text-3xl font-semibold text-gold-premium">100%</span>
                  <span className="text-xs text-[#E0E0E0]/70 uppercase tracking-wider">Rare Natural Essences</span>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 5. How It Works (Scent Map / Steps) */}
      <section id="process" className="py-24 bg-navy-dark relative">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-gold-premium/20 to-transparent" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center space-y-4 mb-20 animate-fade-in">
            <span className="text-xs uppercase tracking-[0.25em] text-gold-premium font-semibold">
              Seamless Ordering
            </span>
            <h2 className="text-3xl sm:text-4xl font-serif font-semibold text-white tracking-wide">
              The Path to Majestic Aroma
            </h2>
            <div className="w-12 h-[1px] bg-gold-premium mx-auto" />
            <p className="text-xs text-grey-light/70 max-w-md mx-auto leading-relaxed">
              Acquiring your customized formula is a straightforward sensory quest.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 relative">
            {/* Visual linking lines for wide layouts */}
            <div className="hidden md:block absolute top-16 left-[16%] right-[16%] h-[1px] bg-gradient-to-r from-gold-premium/5 via-gold-premium/30 to-gold-premium/5 z-0" />

            {/* Step 1 */}
            <div className="flex flex-col items-center text-center space-y-5 relative z-10 p-4">
              <div className="w-16 h-16 rounded-full bg-gold-premium/10 border border-gold-premium/45 flex items-center justify-center text-gold-premium text-lg font-bold font-serif relative">
                <span>01</span>
                <Compass className="h-4 w-4 absolute -bottom-1 -right-1 bg-navy-dark text-gold-premium p-0.5 rounded-full border border-gold-premium" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white tracking-wide">
                Choose Your Fragrance
              </h3>
              <p className="text-xs text-grey-light max-w-xs leading-relaxed">
                Filter our collections or consult the Signature Scent Matcher to locate your precise olfactory identity.
              </p>
            </div>

            {/* Step 2 */}
            <div className="flex flex-col items-center text-center space-y-5 relative z-10 p-4">
              <div className="w-16 h-16 rounded-full bg-gold-premium/10 border border-gold-premium/45 flex items-center justify-center text-gold-premium text-lg font-bold font-serif relative">
                <span>02</span>
                <Package className="h-4 w-4 absolute -bottom-1 -right-1 bg-navy-dark text-gold-premium p-0.5 rounded-full border border-gold-premium" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white tracking-wide">
                Place Your Premium Order
              </h3>
              <p className="text-xs text-grey-light max-w-xs leading-relaxed">
                Add selected formulations to your tray. Provide secure destination details via our secure checkout.
              </p>
            </div>

            {/* Step 3 */}
            <div className="flex flex-col items-center text-center space-y-5 relative z-10 p-4">
              <div className="w-16 h-16 rounded-full bg-gold-premium/10 border border-gold-premium/45 flex items-center justify-center text-gold-premium text-lg font-bold font-serif relative">
                <span>03</span>
                <Truck className="h-4 w-4 absolute -bottom-1 -right-1 bg-navy-dark text-gold-premium p-0.5 rounded-full border border-gold-premium" />
              </div>
              <h3 className="text-lg font-serif font-bold text-white tracking-wide">
                Secure Doorstep Delivery
              </h3>
              <p className="text-xs text-grey-light max-w-xs leading-relaxed">
                Receive your bespoke parcel carefully packaged in signature insulated gold boxes directly at your doorstep.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Customer Testimonials */}
      <section id="reviews" className="py-24 bg-grey-dark/10 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-gold-premium/20 to-transparent" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="text-center space-y-4 mb-20 animate-fade-in">
            <span className="text-xs uppercase tracking-[0.25em] text-gold-premium font-semibold">
              The Sovereign Verdict
            </span>
            <h2 className="text-3xl sm:text-5xl font-serif font-semibold text-white tracking-wide">
              Whispers of Admiration
            </h2>
            <div className="w-16 h-[1.5px] bg-gold-premium mx-auto my-1" />
            <p className="text-xs text-grey-light/70 max-w-sm mx-auto leading-relaxed">
              Discover why connoisseurs choose Shah Habib for their permanent signature scent.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {REVIEWS.map((rev) => (
              <div
                key={rev.id}
                className="bg-grey-dark/30 rounded-2xl p-6 sm:p-8 border border-gold-premium/10 hover:border-gold-premium/30 transition-all flex flex-col justify-between"
              >
                <div className="space-y-4">
                  {/* Rating stars */}
                  <div className="flex items-center space-x-1">
                    {[...Array(rev.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 text-gold-premium fill-gold-premium" />
                    ))}
                  </div>

                  {/* Comment */}
                  <p className="text-sm font-serif italic text-grey-light leading-relaxed">
                    "{rev.comment}"
                  </p>
                </div>

                {/* Author Info */}
                <div className="flex items-center justify-between border-t border-white/5 pt-5 mt-6">
                  <div>
                    <span className="block font-serif font-bold text-white text-sm">
                      {rev.name}
                    </span>
                    <span className="block text-[10px] text-grey-light/45">
                      Verified Collector
                    </span>
                  </div>
                  <span className="text-[10px] text-grey-light/40 font-mono">
                    {rev.date}
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      </section>

      {/* 7. Contact Info and Newsletter Sign-Up */}
      <Newsletter />

      {/* 8. Footer */}
      <footer className="bg-navy-deep border-t border-white/5 py-12 sm:py-16 text-grey-light text-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-12 gap-10 items-start">
            
            {/* Column 1 Logo */}
            <div className="md:col-span-5 space-y-4">
              <div className="flex items-center space-x-2">
                <CrownBadge />
                <span className="text-lg font-serif font-semibold tracking-widest text-white">
                  SHAH HABIB
                </span>
              </div>
              <p className="text-xs leading-relaxed text-grey-light/70 max-w-md">
                Handcrafting sovereign formulas of extreme longevity since inception. Combining old world agarwood resins with modern olfactory precision to build magnificent statement sillage.
              </p>
              
              {/* Social Channels */}
              <div className="flex items-center space-x-4 pt-2">
                <a href="#" className="p-2 bg-white/5 hover:bg-gold-premium hover:text-navy-dark text-grey-light rounded-full transition-colors">
                  <Instagram className="h-4 w-4" />
                </a>
                <a href="#" className="p-2 bg-white/5 hover:bg-gold-premium hover:text-navy-dark text-grey-light rounded-full transition-colors">
                  <Facebook className="h-4 w-4" />
                </a>
                <a href="#" className="p-2 bg-white/5 hover:bg-gold-premium hover:text-navy-dark text-grey-light rounded-full transition-colors">
                  <Dribbble className="h-4 w-4" />
                </a>
              </div>
            </div>

            {/* Column 2 Navigation Links */}
            <div className="md:col-span-3 space-y-4">
              <h4 className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
                Quick Links
              </h4>
              <ul className="space-y-2 text-xs">
                {['Home', 'Shop', 'About', 'Our Process', 'Reviews', 'Contact'].map((label, idx) => {
                  const hrefs = ['#home', '#shop', '#about', '#process', '#reviews', '#contact'];
                  return (
                    <li key={idx}>
                      <a
                        href={hrefs[idx]}
                        onClick={(e) => {
                          e.preventDefault();
                          const target = document.querySelector(hrefs[idx]) as HTMLElement;
                          if (target) window.scrollTo({ top: target.offsetTop - 82, behavior: 'smooth' });
                        }}
                        className="hover:text-white transition-colors block py-0.5"
                      >
                        {label}
                      </a>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Column 3 Legacy details */}
            <div className="md:col-span-4 space-y-4">
              <h4 className="text-xs uppercase tracking-widest text-[#D4AF37] font-semibold">
                The House Philosophy
              </h4>
              <p className="text-xs leading-relaxed text-grey-light/65">
                "Art resides not in bulk production, but in selective, passionate crafting. We release only micro-batches annually, preserving rarity and authentic, unaltered properties of ancient agarwood."
              </p>
              <div className="text-[10px] text-grey-light/40 font-mono font-medium">
                © {new Date().getFullYear()} SHAH HABIB FRAGRANCES PVT. LTD. ALL REGISTERED ROYAL RESERVES RESERVED.
              </div>
            </div>

          </div>
        </div>
      </footer>

      {/* --- FLOATING NOTIFICATION / CART DRAWER / QUICK VIEW INTERACTIVE PORTALS --- */}

      {/* Cart Sidebar panel */}
      <AnimatePresence>
        {isCartOpen && (
          <CartSidebar
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            cartItems={cart}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onCheckout={handleCheckoutSubmit}
          />
        )}
      </AnimatePresence>

      {/* Product Detail Quick View modal */}
      <AnimatePresence>
        {selectedProduct && (
          <ProductDetailModal
            product={selectedProduct}
            onClose={() => setSelectedProduct(null)}
            onAddToCart={handleAddToCart}
          />
        )}
      </AnimatePresence>

      {/* Interactive Scent Quiz Matcher */}
      <AnimatePresence>
        {isQuizOpen && (
          <div
            id="quiz-backdrop"
            onClick={() => setIsQuizOpen(false)}
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              id="quiz-card"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-navy-dark border border-gold-premium/25 max-w-lg w-full rounded-2xl overflow-hidden p-6 sm:p-8 relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                id="close-quiz-btn"
                onClick={() => setIsQuizOpen(false)}
                className="absolute top-4 right-4 p-2 bg-white/5 hover:bg-gold-premium hover:text-navy-dark rounded-full text-grey-light transition-all cursor-pointer"
                aria-label="Close scent matcher"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="text-center space-y-1 mb-8">
                <CrownBadge />
                <h3 className="text-xl font-serif font-bold text-white tracking-wide">
                  Find Your Signature Aura
                </h3>
                <p className="text-xs text-grey-light/75">
                  Answer 2 quick matches to find your customized Shah Habib formula.
                </p>
              </div>

              {!matchedProduct ? (
                <div className="space-y-6">
                  {/* Question 1 */}
                  <div className="space-y-3">
                    <label className="block text-xs uppercase tracking-wider text-gold-premium font-semibold">
                      Step 1: Your Preferred Occasion / Time of Day
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <button
                        onClick={() => handleScentQuiz('occasion', 'day')}
                        className={`p-3.5 rounded-xl border text-xs text-center transition-all cursor-pointer ${
                          quizAnswers.occasion === 'day'
                            ? 'bg-gold-premium/15 border-gold-premium text-white font-bold'
                            : 'bg-navy-deep border-white/5 text-grey-light hover:border-white/20'
                        }`}
                      >
                        Bright Days & Meetings
                      </button>
                      <button
                        onClick={() => handleScentQuiz('occasion', 'night')}
                        className={`p-3.5 rounded-xl border text-xs text-center transition-all cursor-pointer ${
                          quizAnswers.occasion === 'night'
                            ? 'bg-gold-premium/15 border-gold-premium text-white font-bold'
                            : 'bg-navy-deep border-white/5 text-grey-light hover:border-white/20'
                        }`}
                      >
                        Galas & Starry Nights
                      </button>
                    </div>
                  </div>

                  {/* Question 2 */}
                  <div className="space-y-3">
                    <label className="block text-xs uppercase tracking-wider text-gold-premium font-semibold">
                      Step 2: Olfactory Note Preference
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      {[
                        { label: 'Deep Woody Agarwood', id: 'oud' },
                        { label: 'Sweet Madagascar Amber', id: 'amber' },
                        { label: 'Spicy Tuscan Leather', id: 'leather' },
                        { label: 'Crisp Salty Aquatic', id: 'aquatic' },
                      ].map((item) => (
                        <button
                          key={item.id}
                          onClick={() => handleScentQuiz('notePreference', item.id)}
                          className={`p-3 rounded-xl border text-xs text-center transition-all cursor-pointer ${
                            quizAnswers.notePreference === item.id
                              ? 'bg-gold-premium/15 border-gold-premium text-white font-bold'
                              : 'bg-navy-deep border-white/5 text-grey-light hover:border-white/10 hover:border-white/20'
                          }`}
                        >
                          {item.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-navy-deep rounded-2xl p-5 border border-gold-premium/20 flex flex-col items-center text-center space-y-4"
                >
                  <span className="text-[10px] font-bold text-gold-premium tracking-[0.2em] uppercase">
                    Your Signature Scent Match
                  </span>
                  
                  <div className="w-28 h-28 bg-navy-dark rounded-full p-2 border border-gold-premium/15 flex items-center justify-center overflow-hidden">
                    <img
                      src={matchedProduct.image}
                      alt={matchedProduct.name}
                      className="w-full h-full object-cover rounded-full"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div>
                    <h4 className="text-lg font-serif font-bold text-white">
                      {matchedProduct.name}
                    </h4>
                    <p className="text-xs text-gold-premium italic font-serif mt-0.5">
                      "{matchedProduct.tagline}"
                    </p>
                  </div>

                  <p className="text-xs text-grey-light leading-relaxed max-w-xs">
                    {matchedProduct.description}
                  </p>

                  <div className="flex items-center space-x-3 w-full pt-2">
                    <button
                      id="reset-quiz-inner"
                      onClick={resetScentQuiz}
                      className="flex-1 bg-transparent text-white border border-white/10 hover:border-gold-premium text-[11px] font-semibold uppercase tracking-wider py-3 rounded-xl transition-all cursor-pointer"
                    >
                      Retry Quiz
                    </button>
                    <button
                      id="quick-add-matched-quiz"
                      onClick={() => {
                        handleAddToCart(matchedProduct);
                        setIsQuizOpen(false);
                        resetScentQuiz();
                      }}
                      className="flex-1 bg-gold-premium text-navy-dark text-[11px] font-bold uppercase tracking-wider py-3 rounded-xl transition-all hover:bg-gold-light cursor-pointer border border-gold-premium"
                    >
                      Add & Buy - ₹{matchedProduct.price.toLocaleString('en-IN')}
                    </button>
                  </div>
                </motion.div>
              )}
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* GORGEOUS CHECKOUT SUCCESS CONFIRMATION OVERLAY */}
      <AnimatePresence>
        {lastCompletedOrder && (
          <div
            id="order-success-backdrop"
            className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto"
          >
            <motion.div
              id="order-success-card"
              initial={{ opacity: 0, scale: 0.9, y: 30 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 30 }}
              className="bg-navy-dark border border-gold-premium/30 max-w-lg w-full rounded-2xl overflow-hidden p-6 sm:p-8 text-center space-y-6"
            >
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="h-8 w-8 stroke-[1.5] animate-bounce" />
              </div>

              <div className="space-y-2">
                <h3 className="text-2xl font-serif font-bold text-white tracking-wide">
                  Your Imperial Sealed Order is Confirmed
                </h3>
                <p className="text-xs text-grey-light/80 max-w-sm mx-auto leading-relaxed">
                  Excellent choice. Shah Habib’s master perfumers have begun sealing your bottle allocations under precise conditions.
                </p>
              </div>

              {/* Order Specifics */}
              <div className="bg-navy-deep rounded-xl p-4 text-xs text-left divide-y divide-white/5 space-y-3.5 border border-white/5">
                <div className="flex justify-between items-center text-grey-light">
                  <span>Sovereign Order Identifier:</span>
                  <span className="font-mono font-bold text-white">{lastCompletedOrder.orderId}</span>
                </div>
                <div className="pt-3 flex justify-between items-center text-grey-light">
                  <span>Purchased Formulations:</span>
                  <span className="text-right text-white font-medium max-w-[200px] truncate">
                    {lastCompletedOrder.items.map((i) => `${i.product.name} (x${i.quantity})`).join(', ')}
                  </span>
                </div>
                <div className="pt-3 flex justify-between items-center text-sm font-semibold">
                  <span className="text-grey-light">Imperial Total Computed:</span>
                  <span className="font-mono text-gold-premium">₹{lastCompletedOrder.amount.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="flex items-center space-x-2 justify-center text-[10px] text-grey-light/50">
                <Truck className="h-4 w-4 text-gold-premium" />
                <span>ETA: Premium Air Courier delivered within 48-72 Hours.</span>
              </div>

              <button
                id="success-ok-dismiss-btn"
                onClick={() => setLastCompletedOrder(null)}
                className="w-full bg-gold-premium text-navy-dark font-sans text-xs uppercase tracking-widest font-extrabold py-3.5 rounded-xl border border-gold-premium hover:bg-transparent hover:text-gold-premium transition-all duration-300 cursor-pointer shadow-lg shadow-gold-premium/10"
              >
                Close Statement Summary
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

// Small luxury gold crown emblem reusable tag
function CrownBadge() {
  return (
    <div className="w-8 h-8 rounded-full bg-gold-premium/15 border border-gold-premium/40 flex items-center justify-center text-gold-premium">
      <CrownIcon />
    </div>
  );
}

// Reusable SVG Crown path matching brand feel
function CrownIcon() {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="16"
      height="16"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M2.2 21h19.6" />
      <path d="M5 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
      <path d="M19 18a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
      <path d="M12 8a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
      <path d="m5 14 3-7 4 3 4-3 3 7" />
    </svg>
  );
}
