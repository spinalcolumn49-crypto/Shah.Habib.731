import royalOudImg from './assets/images/royal_oud_1781157841417.png';
import midnightAmberImg from './assets/images/midnight_amber_1781157856193.png';
import saffronElixirImg from './assets/images/saffron_elixir_1781157870065.png';
import coastalBreezeImg from './assets/images/coastal_breeze_1781157881601.png';
import heroBannerImg from './assets/images/perfume_hero_banner_1781157902380.png';

import { Product, Review } from './types';

export const HERO_BANNER_IMAGE = heroBannerImg;

export const PRODUCTS: Product[] = [
  {
    id: 'royal-oud',
    name: 'Royal Oud',
    tagline: 'Woody, warm, and sensual',
    description: 'A deep, mysterious journey through ancient agarwood forests, detailed with golden saffron resins.',
    fullDescription: 'Indulge in the magnificence of Royal Oud. Handcrafted with authentic Indian Agarwood (Oud) and balanced with rare cedarwood and musk, this fragrance radiates status and timeless elegance. Made for those who command respect.',
    price: 2499,
    image: royalOudImg,
    category: 'Woody',
    notes: {
      top: 'Sichuan Pepper, Cardamom, Rosewood',
      heart: 'Agarwood (Oud), Sandalwood, Vetiver',
      base: 'Tonka Bean, Vanilla, Amber'
    },
    volume: '100ml / 3.4 FL.OZ.',
    intensity: 'Intense',
    rating: 4.9
  },
  {
    id: 'midnight-amber',
    name: 'Midnight Amber',
    tagline: 'Sweet amber with vanilla & musk',
    description: 'A magnetic fragrance capturing the essence of starry nights and warm whispers of vanilla.',
    fullDescription: 'Midnight Amber is an intimate, luxurious blend designed for evening elegance. Sweet Baltic amber combines with deep Indonesian patchouli and Madagascar vanilla orchid, producing a rich, irresistible aroma that lingers on the skin.',
    price: 2999,
    image: midnightAmberImg,
    category: 'Sweet',
    notes: {
      top: 'Bergamot, Sweet Mandarin, Ambergris',
      heart: 'Madagascar Vanilla Orchid, Benzoin, Jasmine',
      base: 'White Musk, Indonesian Patchouli, Labdanum'
    },
    volume: '100ml / 3.4 FL.OZ.',
    intensity: 'Intense',
    rating: 4.8
  },
  {
    id: 'saffron-elixir',
    name: 'Saffron Elixir',
    tagline: 'Spicy saffron & leather',
    description: 'Bold, structured, and luxurious; a commanding statement of rich Tuscan leather and spiced crimson saffron.',
    fullDescription: 'Saffron Elixir is high art in liquid form. Striking cashmere woods, rugged black leather, and hand-selected saffron threads fuse together to create a perfume that is simultaneously warm, smoky, spicy, and deeply sophisticated.',
    price: 3499,
    image: saffronElixirImg,
    category: 'Spicy',
    notes: {
      top: 'Crimson Saffron, Juniper Berries, Grapefruit',
      heart: 'Black Leather, Violet, Cashmere Woods',
      base: 'Raspberry, Vetiver, Amber resin'
    },
    volume: '100ml / 3.4 FL.OZ.',
    intensity: 'Intense',
    rating: 5.0
  },
  {
    id: 'coastal-breeze',
    name: 'Coastal Breeze',
    tagline: 'Fresh aquatic & citrus',
    description: 'A bright, crisp breath of maritime freshness coupled with zesty Italian lemon and green mint.',
    fullDescription: 'For the modern connoisseur seeking lightness and clarity: Coastal Breeze channels the energy of sea spray colliding with volcanic coastal rocks. Uplifting citrus top notes make place for a sophisticated salty mineral dry-down that ensures daytime confidence.',
    price: 1999,
    image: coastalBreezeImg,
    category: 'Fresh',
    notes: {
      top: 'Italian Lemon, Bergamot, Ocean Accord',
      heart: 'Crushed Mint Leaves, Rosemary, Lavender',
      base: 'Cedarwood, Amberwood, Sea Moss'
    },
    volume: '100ml / 3.4 FL.OZ.',
    intensity: 'Medium',
    rating: 4.7
  }
];

export const REVIEWS: Review[] = [
  {
    id: 'rev-1',
    name: 'Ahmed R.',
    rating: 5,
    comment: "Best long lasting perfume I've ever used! The agarwood scent in Royal Oud is incredibly true and rich, lasting for well over 12 hours.",
    date: '2026-05-18',
    verified: true
  },
  {
    id: 'rev-2',
    name: 'Fatima K.',
    rating: 5,
    comment: "Royal Oud is my new signature scent. It's majestic, mysterious, and commands so many compliments whenever I enter a room. Magnificent branding!",
    date: '2026-06-02',
    verified: true
  },
  {
    id: 'rev-3',
    name: 'Sanya M.',
    rating: 5,
    comment: "Amazing packaging and quick delivery. Saffron Elixir is stunningly luxurious — the smoky leather and sweet saffron notes are blended to perfection.",
    date: '2026-06-10',
    verified: true
  }
];
