import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowUpRight, X } from "lucide-react";

// Fade-Down animation variant for Nav elements
const fadeDownVariants = {
  initial: { opacity: 0, y: -20 },
  animate: (index: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: index * 0.1,
      duration: 0.5,
      ease: [0.22, 1, 0.36, 1],
    },
  }),
};

// Fade-Up animation variant for Stats row & bottom content components
const fadeUpVariants = {
  initial: { opacity: 0, y: 32 },
  animate: (index: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      delay: index * 0.12,
      duration: 0.6,
      ease: [0.22, 1, 0.36, 1],
    },
  }),
};

// Heading clip-reveal slide-up animation variant
const headingVariants = {
  initial: { y: "110%" },
  animate: (wordIndex: number) => ({
    y: 0,
    transition: {
      delay: 0.4 + wordIndex * 0.14,
      duration: 0.7,
      ease: [0.22, 1, 0.36, 1],
    },
  }),
};

const navLinks = ["Story", "Expertise", "Studios", "Feedback"];

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const statsData = [
    { value: "300", label: "CRAFTED\nBRANDS" },
    { value: "200", label: "DIGITAL\nPRODUCTS" },
    { value: "100", label: "VENTURES\nFUNDED" },
  ];

  return (
    <div className="relative min-h-screen w-full overflow-hidden bg-white text-black font-sans antialiased flex flex-col justify-between selection:bg-[#5E0ED7]/25 selection:text-black">
      
      {/* 1. Viewport Filling Video Background */}
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover z-0 pointer-events-none"
      >
        <source
          src="https://d8j0ntlcm91z4.cloudfront.net/user_38xzZboKViGWJOttwIXH07lWA1P/hf_20260517_222138_3e3205be-3364-417b-a64a-bfe087acbec4.mp4"
          type="video/mp4"
        />
        Your browser does not support the video tag.
      </video>

      {/* 2. Soft Elegant Backdrop glass plate to ensure absolute high contrast & text legibility */}
      <div className="absolute inset-0 bg-white/75 backdrop-blur-xs z-10 pointer-events-none" />

      {/* 3. Screen content container */}
      <div className="relative z-20 min-h-screen w-full flex flex-col justify-between">
        
        {/* --- NAVIGATION BAR --- */}
        <header className="w-full flex items-center justify-between px-5 sm:px-8 md:px-12 pt-5 md:pt-6 h-20">
          
          {/* Logo element (fadeDown index 0) */}
          <motion.div
            custom={0}
            variants={fadeDownVariants}
            initial="initial"
            animate="animate"
            className="flex items-center space-x-3"
          >
            <div className="w-8 h-8 rounded-full border-2 border-[#5E0ED7] flex items-center justify-center shrink-0">
              <div className="w-2.5 h-2.5 rounded-full bg-[#5E0ED7]"></div>
            </div>
            <span className="font-semibold tracking-widest text-[#000] uppercase text-sm leading-none pt-0.5">
              Habib
            </span>
          </motion.div>

          {/* Desktop Nav Links (center, visible md+) (fadeDown index 1 to 4) */}
          <nav className="hidden md:flex items-center space-x-10">
            {navLinks.map((link, index) => (
              <motion.a
                key={link}
                href={`#${link.toLowerCase()}`}
                custom={index + 1}
                variants={fadeDownVariants}
                initial="initial"
                animate="animate"
                className="text-sm font-semibold tracking-widest uppercase text-black hover:text-[#5E0ED7] transition-colors"
              >
                {link}
              </motion.a>
            ))}
          </nav>

          {/* Mobile menu trigger (right) (fadeDown index 5) */}
          <motion.div
            custom={5}
            variants={fadeDownVariants}
            initial="initial"
            animate="animate"
          >
            <button
              onClick={() => setIsMobileMenuOpen(true)}
              className="w-9 h-9 rounded-full bg-black flex flex-col items-center justify-center gap-1 hover:opacity-85 active:scale-95 transition-all cursor-pointer"
              aria-label="Open navigation menu"
            >
              <span className="w-4 h-0.5 bg-white block" />
              <span className="w-4 h-0.5 bg-white block" />
              <span className="w-4 h-0.5 bg-white block" />
            </button>
          </motion.div>
        </header>

        {/* --- MOBILE MENU OVERLAY --- */}
        <AnimatePresence>
          {isMobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 bg-white z-50 flex flex-col p-5 sm:p-8 md:p-12 text-black font-sans"
            >
              <div className="flex items-center justify-between">
                {/* Logo replica */}
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full border-2 border-[#5E0ED7] flex items-center justify-center shrink-0">
                    <div className="w-2.5 h-2.5 rounded-full bg-[#5E0ED7]"></div>
                  </div>
                  <span className="font-semibold tracking-widest uppercase text-sm pt-0.5 text-black">
                    Habib
                  </span>
                </div>

                {/* Close Hamburger */}
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="w-9 h-9 rounded-full bg-black text-white flex items-center justify-center hover:opacity-85 active:scale-95 transition-all cursor-pointer"
                  aria-label="Close menu"
                >
                  <X className="w-4 h-4 text-white stroke-[2.5]" />
                </button>
              </div>

              {/* Navigation list */}
              <div className="flex flex-col gap-8 mt-16 pl-2">
                {navLinks.map((link) => (
                  <a
                    key={link}
                    href={`#${link.toLowerCase()}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="text-3xl font-semibold tracking-widest uppercase text-black hover:text-[#5E0ED7] transition-colors"
                  >
                    {link}
                  </a>
                ))}
              </div>

              {/* Bottom aligned action CTA */}
              <div className="mt-auto pt-8 pl-2">
                <a
                  href="#work"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="inline-flex items-center gap-2 text-xl font-semibold tracking-widest uppercase text-[#5E0ED7] hover:opacity-80 transition-opacity"
                >
                  Work With Us
                  <ArrowUpRight className="w-6 h-6 stroke-[2.5]" />
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* --- STATS ROW (Vertically Centered, Right Aligned) --- */}
        <section className="flex-1 flex items-center justify-end px-5 sm:px-8 md:px-12 py-8 md:py-0">
          <div className="flex items-center gap-5 sm:gap-8 md:gap-10">
            {statsData.map((stat, idx) => (
              <motion.div
                key={idx}
                custom={idx + 2} // custom triggers: custom=2,3,4
                variants={fadeUpVariants}
                initial="initial"
                animate="animate"
                className="text-right"
              >
                {/* Custom clamped font scale, weight 600 */}
                <div
                  style={{ fontSize: "clamp(1.5rem, 5vw, 3.5rem)" }}
                  className="font-semibold text-black leading-none flex items-start justify-end"
                >
                  <span className="text-[#5E0ED7] leading-none select-none" style={{ fontSize: "0.5em" }}>
                    +
                  </span>
                  <span>{stat.value}</span>
                </div>
                {/* Label stacked using line breaks, whitespace-pre-line */}
                <p className="text-[10px] sm:text-xs md:text-sm font-semibold tracking-widest uppercase text-black font-sans leading-tight whitespace-pre-line mt-1.5">
                  {stat.label}
                </p>
              </motion.div>
            ))}
          </div>
        </section>

        {/* --- BOTTOM CONTENT SECTION --- */}
        <footer className="w-full flex flex-col gap-6 md:gap-12 px-5 sm:px-8 md:px-12 pb-8 md:pb-12">
          
          {/* Row A: Bold tagline (wrap) + Work With Us link */}
          <div className="flex items-center justify-between gap-4">
            
            {/* Tagline Paragraph (fadeUp index 5) */}
            <motion.p
              custom={5}
              variants={fadeUpVariants}
              initial="initial"
              animate="animate"
              className="text-[10px] sm:text-xs md:text-sm font-semibold tracking-widest uppercase text-black font-sans max-w-[130px] sm:max-w-[160px] md:max-w-xs leading-normal"
              dangerouslySetInnerHTML={{
                __html: "Shaping Bold /<br />Visions Into Power /<br />For Your Tribe",
              }}
            />

            {/* CTA action link (fadeUp index 6) */}
            <motion.div
              custom={6}
              variants={fadeUpVariants}
              initial="initial"
              animate="animate"
            >
              <a
                href="#work"
                className="inline-flex items-center gap-2 text-base sm:text-xl md:text-2xl font-semibold tracking-widest uppercase text-[#5E0ED7] hover:opacity-80 transition-opacity whitespace-nowrap"
              >
                Work With Us
                <ArrowUpRight className="w-[18px] h-[18px] sm:w-[22px] sm:h-[22px] shrink-0 stroke-[2.5]" />
              </a>
            </motion.div>
          </div>

          {/* Row B: Detailed explanation (left) + Stacked main header (right) */}
          <div className="flex items-end justify-between gap-3 sm:gap-4">
            
            {/* Detailed statement (fadeUp index 7) */}
            <motion.p
              custom={7}
              variants={fadeUpVariants}
              initial="initial"
              animate="animate"
              className="w-[120px] sm:w-[180px] md:w-[280px] shrink-0 text-[9px] sm:text-xs md:text-sm font-semibold tracking-widest uppercase text-black/90 font-sans text-left md:text-right leading-relaxed mb-1 sm:mb-2 md:mb-5"
            >
              Creative Studios Built Around Elevating Your Vision Into Striking Reality
            </motion.p>

            {/* Stacked main reveal heading */}
            <div className="flex flex-col items-end">
              {["Fearless", "Vision", "Delivered"].map((word, wordIndex) => (
                <div key={wordIndex} className="overflow-hidden">
                  <motion.div
                    custom={wordIndex}
                    variants={headingVariants}
                    initial="initial"
                    animate="animate"
                    style={{ fontSize: "clamp(2rem, 9vw, 9rem)", lineHeight: 0.88 }}
                    className="font-semibold text-black uppercase text-right tracking-tight sm:tracking-normal"
                  >
                    {word}
                  </motion.div>
                </div>
              ))}
            </div>

          </div>

        </footer>

      </div>
    </div>
  );
}
