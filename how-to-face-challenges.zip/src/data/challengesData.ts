import {
  ChallengeType,
  ChallengeStep,
  MindsetTip,
  InspirationQuote,
  PracticalStrategy,
  SuccessStory,
  ChecklistItem,
  FaqItem,
} from "../types";

export const challengeTypes: ChallengeType[] = [
  {
    id: "personal",
    title: "Personal Challenges",
    description: "Obstacles relating to individual growth, identity, relationships, stress management, and self-esteem.",
    iconName: "User",
    colorClass: "text-amber-600",
    bgClass: "bg-amber-50 border-amber-200/60",
    examples: ["Navigating relationship conflicts", "Overcoming low self-worth", "Breaking unhealthy habits"],
  },
  {
    id: "professional",
    title: "Professional Challenges",
    description: "Career blocks, workload overwhelm, work-life imbalance, career transitions, and professional imposter syndrome.",
    iconName: "Briefcase",
    colorClass: "text-blue-600",
    bgClass: "bg-blue-50 border-blue-200/60",
    examples: ["Adapting to corporate changes", "Managing severe burnout", "Upskilling under pressure"],
  },
  {
    id: "emotional",
    title: "Emotional Challenges",
    description: "Processing grief, healing from old wounds, dealing with chronic anxiety, and learning how to emotionally self-regulate.",
    iconName: "Heart",
    colorClass: "text-rose-600",
    bgClass: "bg-rose-50 border-rose-200/60",
    examples: ["Coping with sudden loss", "Releasing persistent anxiety", "Practicing boundary setting"],
  },
  {
    id: "financial",
    title: "Financial Challenges",
    description: "Economic setbacks, managing debt, loss of income, budgeting struggles, and rebuilding financial security.",
    iconName: "Coins",
    colorClass: "text-emerald-600",
    bgClass: "bg-emerald-50 border-emerald-200/60",
    examples: ["Rebounding after job loss", "Creating a robust debt-payoff plan", "Overcoming scarcity mindset"],
  },
  {
    id: "health",
    title: "Health & Vitality Challenges",
    description: "Living with chronic illnesses, rehabilitating severe physical injuries, or coping with sleep and fatigue issues.",
    iconName: "Activity",
    colorClass: "text-indigo-600",
    bgClass: "bg-indigo-50 border-indigo-200/60",
    examples: ["Adapting to a new medical diagnosis", "Restoring mobility after an injury", "Improving daily energy levels"],
  },
];

export const challengeSteps: ChallengeStep[] = [
  {
    number: 1,
    title: "Accept & Acknowledge",
    brief: "Stop fighting reality and embrace your starting situation.",
    detailed: "Denying or resisting a challenge drains mental energy. By accepting that a challenge exists, you shift your brain from a state of emotional panic into logical problem-solving. This isn't surrender—it's establishing coordinates on your map.",
    actionableTip: "Write down the objective facts of your situation in a single, simple sentence. Exclude any negative self-judgment or catastrophic commentary.",
  },
  {
    number: 2,
    title: "Plan & Deconstruct",
    brief: "Break down the looming mountain into manageable pebbles.",
    detailed: "Huge setbacks paralyze action because they feel too vast to tackle at once. Deconstruction is the art of breaking a big problem into bite-sized segments. If you don't know the full path, focus exclusively on mapping out the next 3 steps.",
    actionableTip: "Identify the absolute smallest micro-step you can execute in under 15 minutes that is directly related to solving the issue.",
  },
  {
    number: 3,
    title: "Take Decisive Action",
    brief: "Commit to doing the work, even when motivation is low.",
    detailed: "Fear and doubt thrive in stagnation. Action is the ultimate antidote to anxiety. Do not wait for perfect conditions or high motivation—initiation creates momentum. Real, imperfect action beats idealized planning any day.",
    actionableTip: "Set an alarm for 10 minutes, shut off all notifications, and focus strictly on that smallest micro-step. Just start.",
  },
  {
    number: 4,
    title: "Stay Consistent",
    brief: "Build resilience through tiny, daily repeated micro-wins.",
    detailed: "Great shifts are not built in a day of heroic effort; they are built through quiet acts of daily showing up. Establishing tiny, non-negotiable rituals keeps you moving forward, slowly compounding minor progress into irreversible, sweeping change.",
    actionableTip: "Commit to spending just 10-15 minutes every single morning advancing your plan, regardless of how you emotionally feel that day.",
  },
  {
    number: 5,
    title: "Reflect & Grow",
    brief: "Extract wisdom from your bruises to level up your toolkit.",
    detailed: "Challenges are raw computational data for personal evolution. Once the storm settles or progress starts, examine what worked, what failed, and how you've changed. This converts a difficult experience into fuel for your lifelong narrative.",
    actionableTip: "Ask yourself: 'What is the one major insight this obstacle has taught me about my grit or creativity that I didn't know before?'",
  },
];

export const mindsetTips: MindsetTip[] = [
  {
    id: "intelligence",
    concept: "Views on Failure & Errors",
    fixedMindset: "\"I failed, which proves I'm simply of limited capacity or skill. I should play it safe and stay inside my comfortable bubble.\"",
    growthMindset: "\"Failure is not an identity; it is localized feedback. It indicates my current method is incomplete. I can study this feedback to adapt and try again.\"",
    actionableShift: "When something breaks, rephrase 'I'm bad at this' to 'I haven't mastered this specific technique yet — but I am on my way.'",
  },
  {
    id: "effort",
    concept: "Value of Struggle and Effort",
    fixedMindset: "\"If I have natural talent, this should be effortless. The fact that I'm struggling means I'm a fraud or lack inherent ability.\"",
    growthMindset: "\"Struggle is the feeling of neuroplasticity in action. Muscle grows when strained, and so does capability. Effort is the master key to mastership.\"",
    actionableShift: "Reframe intense cognitive or physical focus as an intentional 'workout' where discomfort represents actual structural progress.",
  },
  {
    id: "feedback",
    concept: "Handling Constructive Criticism",
    fixedMindset: "\"Criticism is a direct personal insult. I feel attacked and must immediately defend my self-worth by ignoring the helper or lashing out.\"",
    growthMindset: "\"Criticism is an external perspective on my output, not my worth. Useful suggestions guide my adjustments; unhelpful ones can be quietly set aside.\"",
    actionableShift: "When receiving critique, pause and write down only the actionable metrics, ignoring any sharp delivery or emotional undertones.",
  },
  {
    id: "obstacles",
    concept: "Confronting Active Setbacks",
    fixedMindset: "\"This change in plans has totally ruined my efforts. Life is uniquely unfair to me and I should just abandon my goals altogether.\"",
    growthMindset: "\"An obstacle is a redirection indicator, not a stop sign. It forces me to acquire a workaround skill that will make me far more resilient.\"",
    actionableShift: "When a path is blocked, actively brainstorm three alternative pathways instead of mourning the closed door.",
  },
];

export const inspirationQuotes: InspirationQuote[] = [
  {
    id: "1",
    text: "The oak fought the wind and was broken, the willow bent when it must and survived.",
    author: "Robert Jordan",
    context: "On the ultimate strength of flexibility and emotional adaptability."
  },
  {
    id: "2",
    text: "The impediment to action advances action. What stands in the way becomes the way.",
    author: "Marcus Aurelius",
    context: "On Stoic redirection—turning external obstacles into primary fuel."
  },
  {
    id: "3",
    text: "You should never view your challenges as a disadvantage. Instead, it's important for you to understand that your experience facing and overcoming adversity is actually one of your biggest advantages.",
    author: "Michelle Obama",
    context: "On how past struggles build irreplaceable practical grit."
  },
  {
    id: "4",
    text: "Although the world is full of suffering, it is also full of the overcoming of it.",
    author: "Helen Keller",
    context: "On the enduring, triumphant capacity of the human spirit."
  },
];

export const practicalStrategies: PracticalStrategy[] = [
  {
    id: "strat-journaling",
    title: "Anxiety-Decoupling Journaling",
    description: "A simple template to pull chaos out of your mind and structure it logically into facts, emotions, and responses.",
    iconName: "BookOpen",
    tool: "The Rule of 3 Lists",
    exercise: "Write three columns on a sheet: 1) What is 100% out of my control right now. 2) What is inside my direct control. 3) The exact action I will execute next in my circle of control.",
  },
  {
    id: "strat-meditation",
    title: "Grounding Box-Breathing",
    description: "A physiological technique used by high-stress professionals to rapidly reset the autonomic nervous system.",
    iconName: "Compass",
    tool: "4-4-4-4 Cycle Reset",
    exercise: "Inhale fully for 4 seconds, hold your breath at the capacity peak for 4 seconds, exhale fully for 4 seconds, and hold the empty lungs for 4 seconds. Repeat 5 times.",
  },
  {
    id: "strat-goals",
    title: "Micro-Goal Calibration",
    description: "The practice of creating hyper-specific progress markers that prevent cognitive overwhelm and release small success dopamine.",
    iconName: "Target",
    tool: "The 'Next-Ten' Minutes rule",
    exercise: "Stop thinking about the month or week ahead. Ask yourself: 'What is the absolute single best action I can complete over the next ten minutes?' Write it down and execute.",
  },
  {
    id: "strat-support",
    title: "Vulnerability & Social Support",
    description: "Breaking insulation. Seeking guidance and perspective to build a safety net of feedback and care.",
    iconName: "Users",
    tool: "The Specific Ask Framework",
    exercise: "Reach out to one trusted person. Say: 'I am working through a challenge. I don't need you to fix it, but I would really value 10 minutes of venting or a neutral sounding board.'",
  },
];

export const successStories: SuccessStory[] = [
  {
    id: "story-elena",
    name: "Elena Rostova",
    age: "31",
    role: "Restaurateur & Chef",
    challenge: "Her newly opened diner suffered a severe kitchen electrical fire, wiping out her entire financial savings and closing down business operations overnight.",
    strategyUsed: "Elena used 'Acceptance' and 'The Specific Ask Framework'. She immediately started transparently detailing her rebuilding efforts on social media to ask her community for helping hands.",
    result: "Within 45 days, 40 local residents volunteered manual labor to paint and clean, while local competitors donated excess hardware to help Elena relaunch her doors.",
    quote: "I learned that asking for help is not a weakness; it is a superpower that invites communal resilience into your dream.",
    avatarUrl: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&q=80&w=200",
  },
  {
    id: "story-marcus",
    name: "Marcus Chen",
    age: "42",
    role: "Software Director",
    challenge: "Suffered a sudden medical stroke, resulting in temporary motor-function loss across his right-dominant arm and leg, leading to profound depression.",
    strategyUsed: "Marcus calibrated 'Micro-Goal tracking' and 'Box-Breathing' exercises to manage severe physical rehabilitation sessions.",
    result: "By setting micro-goals for finger mobility every single afternoon without exception, Marcus fully restored 90% of his fine motor skills over 12 months of daily training.",
    quote: "You don't need to walk a leagues-long road today. You just need to lift one finger, breathe, and trust the compounding nature of time.",
    avatarUrl: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&q=80&w=200",
  },
  {
    id: "story-sarah",
    name: "Sarah Jenkins",
    age: "24",
    role: "Freelance Designer",
    challenge: "Trapped in overwhelming personal credit card debt due to poor financial habits, leading to ongoing creative blocks and imposter syndrome.",
    strategyUsed: "Sarah committed to 'Anxiety-Decoupling Journaling'. She itemized all accounts, set up an automatic avalanche payoff scheme, and blocked high-interest credit lines.",
    result: "Paid down $14,000 of high-interest debt over 18 months, freeing up her mental bandwidth and scaling her freelance agency revenue by 2.5x.",
    quote: "Organizing my financial chaos with systematic metrics completely unlocked my physical creative output. Facing the numbers set me free.",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200",
  },
];

export const dailyChecklistItems: ChecklistItem[] = [
  {
    id: "task-breaths",
    task: "Complete 5 slow cycles of grounding box-breathing to calm your nervous system.",
    category: "mindset",
    difficulty: "Easy",
  },
  {
    id: "task-journal",
    task: "Write down 3 objective facts and 1 direct action for a current worry in your life.",
    category: "reflection",
    difficulty: "Medium",
  },
  {
    id: "task-difficulty",
    task: "Complete 'One Hard Thing' first today, bypassing procrastination.",
    category: "action",
    difficulty: "Challenging",
  },
  {
    id: "task-gratitude",
    task: "Recall or text a person who has supported your growth, expressing clean gratitude.",
    category: "reflection",
    difficulty: "Easy",
  },
  {
    id: "task-walk",
    task: "Engage in 15 minutes of uninterrupted movement (walking or stretching) to disperse mental fog.",
    category: "action",
    difficulty: "Easy",
  },
  {
    id: "task-growth",
    task: "Catch yourself in a self-defeating thought ('I failed again') and actively reframe it with growth mindset language.",
    category: "mindset",
    difficulty: "Medium",
  },
];

export const faqItems: FaqItem[] = [
  {
    id: "faq-giving-up",
    question: "What if I feel completely overwhelmed and feel like giving up?",
    answer: "First, understand that feeling overwhelmed is an biological alarm system on high alert—it is not an indicator of your true ability. When you reach this threshold, stop trying to solve the global problem. Pause and shrink your temporal horizon: don't plan for tomorrow, don't plan for the next hour. Commit purely to resting for the next 30 minutes, or completing just one small, sensory action. Shrink your world until it is small enough for you to handle safely.",
    category: "Resilience",
  },
  {
    id: "faq-timeframe",
    question: "How long does it take to truly overcome an intense challenge?",
    answer: "There path of resilience is highly personal and non-linear. Some adjustments occur within weeks, while others require multiple seasons. Rather than focusing on a temporal finish line—which can generate anticipation anxiety—focus on standardizing your daily system. If your underlying micro-daily habits are robust and adaptive, time is on your side; progress becomes an natural mathematical byproduct of consistency.",
    category: "Expectations",
  },
  {
    id: "faq-others",
    question: "How do I explain my struggles to others without sounding weak?",
    answer: "Weakness is hiding an issue until it collapses under pressure. Explaining your challenge transparently is a mature display of strategic command. Frame your statement using facts and intention: 'I am currently navigating a difficult career transition/health event. I would appreciate some neutral listening, or your tactical feedback on [specific skill], as I work my way through it.' This changes the dynamic from a plea for pity into a professional collaboration on problem-solving.",
    category: "Social Support",
  },
  {
    id: "faq-regression",
    question: "What should I do if I experience a setback or slip back into bad habits?",
    answer: "Regressions are standard, expected components of any growth arc, not failures of the journey. Expecting linear progress is an cognitive cognitive error. When you slip, practice radical self-compassion first: do not waste mental energy on shame. Identify the environmental triggers that preceded the slip, adjust your immediate surroundings, and start your habits again with the very next meal, hour, or decision. A single step backwards does not invalidate the miles you have walked.",
    category: "Consistency",
  },
];
