import { motion } from "motion/react";
import { User, Briefcase, Heart, Coins, Activity, ArrowRight, Lightbulb } from "lucide-react";
import { challengeTypes } from "../data/challengesData";

export default function ChallengeTypes() {
  // Utility maps to map string IDs to Lucide components
  const renderIcon = (iconName: string, className: string) => {
    switch (iconName) {
      case "User":
        return <User className={className} />;
      case "Briefcase":
        return <Briefcase className={className} />;
      case "Heart":
        return <Heart className={className} />;
      case "Coins":
        return <Coins className={className} />;
      case "Activity":
        return <Activity className={className} />;
      default:
        return <Lightbulb className={className} />;
    }
  };

  return (
    <section className="py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center md:max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-blue-100/85 border border-blue-200 text-blue-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <User className="w-3.5 h-3.5 stroke-[2.5]" />
            Classification
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Identifying Your Arena
          </h2>
          <p className="text-slate-600 text-base leading-relaxed">
            Understanding the nature of your struggle is half the battle. Each type of challenge requires a tailored vocabulary and cognitive toolbox to navigate correctly.
          </p>
        </div>

        {/* Cards Row/Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {challengeTypes.map((type, i) => (
            <motion.div
              key={type.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.45, delay: i * 0.08 }}
              className={`p-8 rounded-2xl border ${type.bgClass} flex flex-col justify-between hover:shadow-lg transition-all duration-300`}
            >
              <div>
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-11 h-11 rounded-xl bg-white border border-slate-200 shadow-sm flex items-center justify-center`}>
                    {renderIcon(type.iconName, `w-5.5 h-5.5 ${type.colorClass}`)}
                  </div>
                  <h3 className="text-lg font-bold text-slate-800 tracking-tight">
                    {type.title}
                  </h3>
                </div>

                <p className="text-slate-600 text-sm leading-relaxed mb-6">
                  {type.description}
                </p>

                <div className="pt-5 border-t border-slate-200/50">
                  <h4 className="text-[10px] font-mono tracking-widest uppercase font-semibold text-slate-400 mb-3">
                    Common Impediments
                  </h4>
                  <ul className="space-y-2.5">
                    {type.examples.map((example, idx) => (
                      <li key={idx} className="flex items-start gap-2.5 text-xs text-slate-600 font-medium">
                        <div className="w-1.5 h-1.5 rounded-full bg-slate-400 mt-1.5 shrink-0" />
                        <span>{example}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Button that takes them to checklist category */}
              <div className="mt-8 flex justify-end">
                <a
                  href="#checklist"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-500 hover:text-slate-800 transition-colors"
                >
                  Apply Strategies
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
