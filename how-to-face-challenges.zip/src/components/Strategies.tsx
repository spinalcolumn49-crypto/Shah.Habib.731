import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { BookOpen, Compass, Target, Users, ArrowRight, ShieldCheck, HelpCircle } from "lucide-react";
import { practicalStrategies } from "../data/challengesData";

export default function Strategies() {
  const [activeStratId, setActiveStratId] = useState<string | null>(null);

  const getIcon = (name: string, className: string) => {
    switch (name) {
      case "BookOpen":
        return <BookOpen className={className} />;
      case "Compass":
        return <Compass className={className} />;
      case "Target":
        return <Target className={className} />;
      case "Users":
        return <Users className={className} />;
      default:
        return <ShieldCheck className={className} />;
    }
  };

  return (
    <section id="strategies" className="py-24 bg-white border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center md:max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-indigo-100/85 border border-indigo-200 text-indigo-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <Compass className="w-3.5 h-3.5 stroke-[2.5]" />
            Practical Toolkit
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4 font-sans">
            Real-Life Tactical Strategies
          </h2>
          <p className="text-slate-600 text-base leading-relaxed">
            Theories do not solve crises; actions do. These high-fidelity, research-supported tactical exercises can be integrated into your day in response to active stressors.
          </p>
        </div>

        {/* Strategies Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {practicalStrategies.map((strat, i) => {
            const isExpanded = activeStratId === strat.id;

            return (
              <motion.div
                key={strat.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.45, delay: i * 0.08 }}
                className={`bg-slate-50 border rounded-2xl p-6.5 hover:shadow-xl hover:bg-white transition-all duration-300 relative overflow-hidden flex flex-col justify-between ${
                  isExpanded ? "border-amber-400 bg-white ring-2 ring-amber-400/10 shadow-lg" : "border-slate-200/80"
                }`}
              >
                <div>
                  <div className="flex items-center gap-3.5 mb-5">
                    <div className="w-10 h-10 rounded-xl bg-slate-950 text-white flex items-center justify-center shrink-0 shadow-sm">
                      {getIcon(strat.iconName, "w-5 h-5 text-amber-500")}
                    </div>
                    <h3 className="text-md sm:text-base font-extrabold text-slate-900 tracking-tight">
                      {strat.title}
                    </h3>
                  </div>

                  <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-6">
                    {strat.description}
                  </p>

                  <div className="pt-4 border-t border-slate-200/65">
                    <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest block mb-1">
                      Tool Protocol
                    </span>
                    <span className="text-sm font-bold text-slate-900 block mb-3">
                      {strat.tool}
                    </span>
                  </div>

                  {/* Micro-exercise dropdown/animation area */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.25 }}
                        className="overflow-hidden mt-2"
                      >
                        <div className="bg-amber-50/80 border border-amber-200/50 rounded-xl p-4 mt-2">
                          <span className="text-[10px] font-mono font-bold text-amber-700 uppercase tracking-wider block mb-1.5 flex items-center gap-1">
                            <HelpCircle className="w-3 h-3" />
                            Actionable Exercise
                          </span>
                          <p className="text-xs text-slate-800 leading-relaxed font-medium">
                            {strat.exercise}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="mt-8 pt-2">
                  <button
                    onClick={() => setActiveStratId(isExpanded ? null : strat.id)}
                    className={`w-full py-2.5 px-4 rounded-xl text-xs font-bold transition-all duration-200 flex items-center justify-center gap-1.5 border cursor-pointer ${
                      isExpanded
                        ? "bg-slate-900 text-white border-slate-900 hover:bg-slate-800"
                        : "bg-white text-slate-800 border-slate-200 hover:bg-slate-50 hover:text-slate-950"
                    }`}
                  >
                    {isExpanded ? "Close Instructions" : "Access Exercise"}
                    <ArrowRight className={`w-3.5 h-3.5 transition-transform duration-200 ${isExpanded ? "rotate-90" : ""}`} />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
