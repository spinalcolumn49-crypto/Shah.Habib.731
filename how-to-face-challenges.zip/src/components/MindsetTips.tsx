import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Check, X, ShieldAlert, Sparkles, Smile, ArrowRight } from "lucide-react";
import { mindsetTips } from "../data/challengesData";

export default function MindsetTips() {
  const [activeConceptId, setActiveConceptId] = useState(mindsetTips[0].id);

  const activeTip = mindsetTips.find((m) => m.id === activeConceptId) || mindsetTips[0];

  return (
    <section id="mindset" className="py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center md:max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-amber-100/85 border border-amber-200 text-amber-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <Smile className="w-3.5 h-3.5 stroke-[2.5]" />
            Cognitive Rewiring
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Growth vs. Fixed Mindset
          </h2>
          <p className="text-slate-600 text-base leading-relaxed">
            How we label a hardship determines our physiological ability to respond. Explore how slight adjustments in internal monologue completely unlock problem-solving capacity.
          </p>
        </div>

        {/* Tab Selection */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {mindsetTips.map((tip) => (
            <button
              key={tip.id}
              onClick={() => setActiveConceptId(tip.id)}
              className={`px-5 py-2.5 rounded-xl font-semibold text-xs sm:text-sm tracking-wide transition-all duration-200 cursor-pointer ${
                activeConceptId === tip.id
                  ? "bg-slate-900 text-white shadow-md shadow-slate-900/10"
                  : "bg-white text-slate-600 border border-slate-200 hover:bg-slate-50 hover:text-slate-950"
              }`}
            >
              {tip.concept}
            </button>
          ))}
        </div>

        {/* Interactive Comparison Console */}
        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeConceptId}
              initial={{ opacity: 0, scale: 0.99 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.99 }}
              transition={{ duration: 0.25 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch"
            >
              {/* Fixed Mindset Column */}
              <div className="bg-white p-8 rounded-2xl border border-rose-100/80 shadow-md shadow-rose-50/20 relative flex flex-col justify-between">
                <div>
                  <div className="absolute top-4 right-4 text-[10px] uppercase font-mono tracking-widest text-rose-500 font-bold bg-rose-50 border border-rose-100/80 px-2 py-0.5 rounded">
                    Limiting
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-150 flex items-center justify-center mb-6">
                    <X className="w-5 h-5 text-rose-600 stroke-[2.5]" />
                  </div>
                  <h3 className="text-lg font-extrabold text-slate-950 mb-3">
                    The Fixed Response
                  </h3>
                  <p className="text-slate-600 italic text-sm leading-relaxed">
                    {activeTip.fixedMindset}
                  </p>
                </div>
                <div className="mt-8 pt-5 border-t border-slate-100">
                  <span className="text-[10px] font-mono tracking-wider font-semibold text-rose-400 block uppercase">
                    Neural State
                  </span>
                  <p className="text-xs text-slate-500 mt-1">
                    Triggers survival responses, elevating cortisol levels and temporarily disabling the creative prefrontal cortex.
                  </p>
                </div>
              </div>

              {/* Growth Mindset Column */}
              <div className="bg-slate-900 p-8 rounded-2xl border border-amber-500/15 shadow-xl relative text-white flex flex-col justify-between">
                <div>
                  <div className="absolute top-4 right-4 text-[10px] uppercase font-mono tracking-widest text-amber-500 font-bold bg-amber-500/5 border border-amber-500/15 px-2 py-0.5 rounded">
                    Empowering
                  </div>
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mb-6">
                    <Check className="w-5 h-5 text-amber-500 stroke-[2.5]" />
                  </div>
                  <h3 className="text-lg font-extrabold text-amber-400 mb-3">
                    The Growth Response
                  </h3>
                  <p className="text-slate-300 italic text-sm leading-relaxed">
                    {activeTip.growthMindset}
                  </p>
                </div>
                <div className="mt-8 pt-5 border-t border-slate-800">
                  <span className="text-[10px] font-mono tracking-wider font-semibold text-amber-500/80 block uppercase">
                    Neural State
                  </span>
                  <p className="text-xs text-slate-400 mt-1">
                    Triggers synaptic consolidation, promoting dopamine loops related to self-efficacy and perseverance.
                  </p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Actionable Shift Alert Box */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mt-8 bg-amber-50 border border-amber-100 rounded-2xl p-6 sm:p-8 flex items-start gap-4"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-100 flex items-center justify-center shrink-0 border border-amber-200">
              <Sparkles className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h4 className="text-sm font-extrabold text-slate-950 uppercase tracking-wider mb-1 font-mono">
                Micro-Practice: Concrete Self-Talk Shift
              </h4>
              <p className="text-slate-700 text-sm leading-relaxed mb-3">
                Next time you find yourself stuck on {activeTip.concept.toLowerCase()}, try this reframing practice:
              </p>
              <div className="bg-white border border-slate-200 rounded-lg py-2 px-3 inline-block font-medium text-xs sm:text-sm text-slate-800">
                &ldquo;{activeTip.actionableShift}&rdquo;
              </div>
            </div>
          </motion.div>
        </div>

      </div>
    </section>
  );
}
