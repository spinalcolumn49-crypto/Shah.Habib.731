import React from "react";
import { ArrowUp, Flame, Heart, Copyright } from "lucide-react";

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetId = href.substring(1);
    const element = document.getElementById(targetId);
    if (element) {
      const topOffset = element.getBoundingClientRect().top + window.scrollY - 80;
      window.scrollTo({
        top: topOffset,
        behavior: "smooth",
      });
    }
  };

  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-900 py-16 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Upper footer grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 mb-12">
          
          {/* Logo & Close Note */}
          <div className="md:col-span-5 space-y-4">
            <div className="flex items-center space-x-2.5">
              <div className="w-9 h-9 rounded-xl overflow-hidden border border-amber-500/35 shadow-md shadow-amber-500/10 shrink-0">
                <img
                  src="https://images.unsplash.com/photo-1546182990-dffeafbe841d?auto=format&fit=crop&q=80&w=150"
                  alt="Shah Habib Lion logo"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-md font-bold tracking-tight text-white block">
                Shah Habib
              </span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed max-w-sm">
              &ldquo;The permanent test of life is resilience. It is not about whether you fall, but how many milliseconds it takes you to stand back up, clear your sight, and take the next step.&rdquo;
            </p>
          </div>

          {/* Quick links columns */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-white">
              Navigation
            </h4>
            <ul className="space-y-2">
              {[
                { label: "Our Philosophy", href: "#understand" },
                { label: "Step Paradigm", href: "#steps" },
                { label: "Mindset Rewire", href: "#mindset" },
                { label: "Daily Action Checklist", href: "#checklist" },
              ].map((item) => (
                <li key={item.label}>
                  <a
                    href={item.href}
                    onClick={(e) => handleScrollTo(e, item.href)}
                    className="text-sm text-slate-500 hover:text-white transition-colors"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-4 space-y-3">
            <h4 className="text-xs font-mono font-bold uppercase tracking-wider text-white">
              Sensing Support
            </h4>
            <p className="text-slate-500 text-sm leading-relaxed">
              If you or someone you know is facing extreme distress or sudden life-altering events, please remember that reaching out to humans who care is the ultimate badge of strength. Reach your local service lines—seeking help opens up support.
            </p>
          </div>

        </div>

        {/* Lower copyright bar */}
        <div className="pt-8 border-t border-slate-900 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-1.5 text-xs text-slate-600">
            <Copyright className="w-3.5 h-3.5" />
            <span>2026 Resilience Hub. Created with professional care to promote mental toughness.</span>
          </div>

          {/* Back to top tool */}
          <button
            onClick={handleScrollToTop}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-850 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer"
          >
            <span>Back to top</span>
            <ArrowUp className="w-4 h-4 text-amber-500" />
          </button>
        </div>

      </div>
    </footer>
  );
}
