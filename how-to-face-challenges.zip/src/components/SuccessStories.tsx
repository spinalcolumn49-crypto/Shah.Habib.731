import { motion } from "motion/react";
import { MessageSquare, Quote, Heart, Sparkles } from "lucide-react";
import { successStories } from "../data/challengesData";

export default function SuccessStories() {
  return (
    <section id="stories" className="py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center md:max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-rose-100/85 border border-rose-200 text-rose-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <Heart className="w-3.5 h-3.5 stroke-[2.5]" />
            Empathy & Proof
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4 font-sans">
            Stories of Rebounding
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Resilience is not a theoretical model—it is a proven, physical trait forged by real people in the trenches of hardship. Read how others utilized these principles to navigate their storm.
          </p>
        </div>

        {/* Stories Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {successStories.map((story, i) => (
            <motion.div
              key={story.id}
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-white p-8 rounded-2xl border border-slate-200/80 shadow-md shadow-slate-100/50 hover:shadow-xl hover:border-slate-300 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                {/* Quote Speech Card bubble */}
                <div className="relative bg-slate-50 border border-slate-150 rounded-2xl p-6 mb-8">
                  {/* Small pointer bubble tail */}
                  <div className="absolute -bottom-2.5 left-8 w-5 h-5 bg-slate-50 border-r border-b border-slate-150 rotate-45" />
                  
                  <Quote className="w-8 h-8 text-slate-200 absolute top-4 right-4 pointer-events-none" />
                  
                  <p className="text-slate-700 italic text-sm sm:text-base leading-relaxed font-semibold relative z-10">
                    &ldquo;{story.quote}&rdquo;
                  </p>
                </div>

                <div className="space-y-4">
                  {/* Scenario challenge info */}
                  <div>
                    <span className="text-[10px] font-mono font-bold text-red-500 uppercase tracking-widest block">
                      The Obstacle
                    </span>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium">
                      {story.challenge}
                    </p>
                  </div>

                  {/* Operational path info */}
                  <div>
                    <span className="text-[10px] font-mono font-bold text-amber-600 uppercase tracking-widest block">
                      Resolution Path
                    </span>
                    <p className="text-xs sm:text-sm text-slate-700 font-medium">
                      {story.strategyUsed}
                    </p>
                  </div>

                  {/* Outcome */}
                  <div className="pt-3 border-t border-slate-100">
                    <span className="text-[10px] font-mono font-bold text-emerald-600 uppercase tracking-widest block">
                      The Rebound Outcome
                    </span>
                    <p className="text-xs sm:text-sm text-slate-800 font-bold">
                      {story.result}
                    </p>
                  </div>
                </div>
              </div>

              {/* Bio block at the base */}
              <div className="flex items-center gap-3.5 mt-8 pt-6 border-t border-slate-100">
                <img
                  src={story.avatarUrl}
                  alt={story.name}
                  referrerPolicy="no-referrer"
                  className="w-12 h-12 rounded-full object-cover border-2 border-amber-500/35 shadow-sm shrink-0"
                />
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 leading-tight">
                    {story.name}
                  </h4>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Age {story.age} &bull; {story.role}
                  </p>
                </div>
              </div>

            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
