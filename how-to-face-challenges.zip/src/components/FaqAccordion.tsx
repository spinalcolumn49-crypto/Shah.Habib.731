import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, HelpCircle, Search, Sparkles } from "lucide-react";
import { faqItems } from "../data/challengesData";

export default function FaqAccordion() {
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const handleToggle = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const filteredFaqs = faqItems.filter((faq) => {
    const query = searchQuery.toLowerCase().trim();
    if (!query) return true;
    return (
      faq.question.toLowerCase().includes(query) ||
      faq.answer.toLowerCase().includes(query) ||
      faq.category.toLowerCase().includes(query)
    );
  });

  return (
    <section id="faq" className="py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-1.5 bg-amber-100/85 border border-amber-200 text-amber-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <HelpCircle className="w-3.5 h-3.5 stroke-[2.5]" />
            Inquire Hub
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Frequently Asked Queries
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            Struggling with implementation or feeling lost in cognitive loops? Review common questions on emotional maintenance, social parameters, and resilience.
          </p>
        </div>

        {/* Search tool */}
        <div className="relative mb-8 max-w-xl mx-auto">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none text-slate-400">
            <Search className="w-5 h-5" />
          </div>
          <input
            type="text"
            placeholder="Search FAQs (e.g. 'giving up', 'habits', 'weakness')..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white border border-slate-250 py-3.5 pl-12 pr-4 rounded-xl text-sm text-slate-800 outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-400/10 transition-all font-medium"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery("")}
              className="absolute inset-y-0 right-4 flex items-center text-xs font-bold text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              Clear
            </button>
          )}
        </div>

        {/* Accordions */}
        <div className="space-y-4">
          {filteredFaqs.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-2xl border border-slate-250">
              <p className="text-slate-400 text-sm font-medium">No questions matched your search query. Try another term.</p>
            </div>
          ) : (
            filteredFaqs.map((faq) => {
              const isExpanded = expandedId === faq.id;

              return (
                <div
                  key={faq.id}
                  className={`bg-white border rounded-2xl transition-all duration-300 ${
                    isExpanded ? "border-amber-400/80 shadow-md ring-2 ring-amber-400/5" : "border-slate-200/80 hover:border-slate-300"
                  }`}
                >
                  {/* Trigger Header */}
                  <button
                    onClick={() => handleToggle(faq.id)}
                    className="w-full text-left p-6 flex justify-between items-center gap-4 focus:outline-none cursor-pointer"
                    aria-expanded={isExpanded}
                  >
                    <div className="flex-1">
                      <span className="text-[9px] font-mono font-bold text-amber-600 bg-amber-50 uppercase tracking-widest px-2 py-0.5 rounded border border-amber-100">
                        {faq.category}
                      </span>
                      <h4 className="text-sm sm:text-base font-extrabold text-slate-900 mt-2.5 leading-snug">
                        {faq.question}
                      </h4>
                    </div>

                    <div className={`w-8 h-8 rounded-lg bg-slate-50 flex items-center justify-center shrink-0 border border-slate-200/50 transition-transform duration-350 ${
                      isExpanded ? "rotate-180 bg-amber-50 border-amber-200 text-amber-600" : "text-slate-400"
                    }`}>
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {/* Body Content */}
                  <AnimatePresence initial={false}>
                    {isExpanded && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="overflow-hidden"
                      >
                        <div className="px-6 pb-6 pt-1 border-t border-slate-100 mt-1">
                          <p className="text-slate-600 text-xs sm:text-sm leading-relaxed mb-4">
                            {faq.answer}
                          </p>

                          <div className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-600 bg-amber-50/50 border border-amber-100/60 px-3 py-1 rounded-lg">
                            <Sparkles className="w-3 h-3 text-amber-500" />
                            <span>Action protocol enabled. Deep breaths.</span>
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })
          )}
        </div>

      </div>
    </section>
  );
}
