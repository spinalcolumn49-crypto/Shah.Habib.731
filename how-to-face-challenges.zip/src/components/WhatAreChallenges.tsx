import { motion } from "motion/react";
import { HelpCircle, ShieldAlert, Sparkles, Smile } from "lucide-react";

export default function WhatAreChallenges() {
  const cards = [
    {
      icon: <ShieldAlert className="w-6 h-6 text-amber-600" />,
      title: "Biological Catalyst",
      description: "Throughout human evolution, cognitive growth and psychological fortitude only activated in response to environmental friction. No growth happens in sterile isolation.",
      badge: "Neuroplasticity"
    },
    {
      icon: <Sparkles className="w-6 h-6 text-blue-600" />,
      title: "The Reset Button",
      description: "Stumbling blocks force us to step off automatic pilot. They interrupt repetitive routines, prompting deep internal audits about what truly serves our potential.",
      badge: "Perspective Shift"
    },
    {
      icon: <Smile className="w-6 h-6 text-emerald-600" />,
      title: "Character Sandbox",
      description: "Patience, courage, compassion, and boundaries are invisible metrics. They cannot be built theoretically—they require real stress to be tempered and validated.",
      badge: "Empirical Virtue"
    }
  ];

  return (
    <section id="understand" className="py-24 bg-slate-50 border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center md:max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-amber-100/85 border border-amber-200 text-amber-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <HelpCircle className="w-3.5 h-3.5 stroke-[2.5]" />
            First Principles
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Why Do Challenges Exist?
          </h2>
          <p className="text-slate-600 text-base leading-relaxed">
            We often view obstacles as random, targeted malice from the universe. But when parsed scientifically, challenges prove to be essential components of self-discovery.
          </p>
        </div>

        {/* Bento Grid columns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {cards.map((card, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="bg-white p-8 rounded-2xl border border-slate-200/80 shadow-md shadow-slate-100/50 hover:shadow-xl hover:border-slate-300/80 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center mb-6 border border-slate-150">
                  {card.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{card.title}</h3>
                <p className="text-slate-600 text-sm leading-relaxed mb-6">
                  {card.description}
                </p>
              </div>
              <div>
                <span className="inline-block px-3 py-1 bg-slate-100/80 hover:bg-slate-100 text-slate-500 font-mono text-[10px] font-semibold uppercase tracking-widest rounded-md border border-slate-150 transition-colors">
                  {card.badge}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Callout quote snippet */}
        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="mt-16 bg-gradient-to-r from-slate-900 via-slate-900 to-slate-800 rounded-3xl p-8 sm:p-12 border border-slate-800 text-white shadow-xl flex flex-col md:flex-row items-center justify-between gap-8 text-left"
        >
          <div className="max-w-xl">
            <h4 className="text-amber-400 font-bold text-sm uppercase tracking-wider mb-2 font-mono">
              The Fundamental Choice
            </h4>
            <p className="text-lg text-slate-200 font-medium leading-relaxed">
              &ldquo;Life doesn't happen to you, it happens for you.&rdquo; When you stop asking &ldquo;Why me?&rdquo; and start asking &ldquo;What is this teaching me?&rdquo;, you instantly regain command over your destiny.
            </p>
          </div>
          <button
            onClick={() => {
              const element = document.getElementById("steps");
              if (element) {
                element.scrollIntoView({ behavior: "smooth" });
              }
            }}
            className="whitespace-nowrap px-6 py-3 bg-white text-slate-900 hover:bg-slate-100 rounded-xl font-bold text-sm transition-all shadow-md active:scale-95 cursor-pointer"
          >
            Learn How To Face Them
          </button>
        </motion.div>
      </div>
    </section>
  );
}
