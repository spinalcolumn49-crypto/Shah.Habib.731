import { motion } from "motion/react";
import { Sparkles, ArrowRight, ShieldCheck, HelpCircle } from "lucide-react";

interface HeroProps {
  onStartJourney: () => void;
}

export default function Hero({ onStartJourney }: HeroProps) {
  return (
    <div className="relative min-h-screen bg-[#0f172a] overflow-hidden flex items-center justify-center pt-20">
      {/* Background radial soft lights to simulate atmospheric deep-space backdrop */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Grid Pattern overlay for depth */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b12_1px,transparent_1px),linear-gradient(to_bottom,#1e293b12_1px,transparent_1px)] bg-[size:24px_24px] pointer-events-none" />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-10 pb-16">
        {/* Intro Badge */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-2 bg-slate-800/80 border border-slate-700/50 backdrop-blur-sm px-4 py-1.5 rounded-full mb-6"
        >
          <Sparkles className="w-4.5 h-4.5 text-amber-500 animate-pulse" />
          <span className="text-xs font-semibold tracking-wider text-slate-300 uppercase font-mono">
            Interactive Resilience System
          </span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-white leading-tight mb-6"
        >
          Every Challenge is a <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-400 via-amber-200 to-amber-500">
            Step Forward
          </span>
        </motion.h1>

        {/* Motivational Subtext */}
        <motion.p
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="max-w-2xl mx-auto text-lg sm:text-xl text-slate-300 font-normal leading-relaxed mb-10"
        >
          An immersive, interactive space built to help you navigate hardship. Learn to break down blockages, rewire self-limiting thoughts, and build small daily habits that trigger high-impact gains.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <button
            onClick={onStartJourney}
            className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-amber-500 to-amber-600 text-slate-950 font-bold rounded-xl shadow-lg shadow-amber-500/20 hover:shadow-xl hover:shadow-amber-500/30 hover:scale-[1.03] active:scale-98 transition-all duration-200 flex items-center justify-center gap-2 group cursor-pointer"
          >
            Start Your Journey
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform" />
          </button>
          <a
            href="#checklist"
            className="w-full sm:w-auto px-8 py-4 bg-slate-800/80 hover:bg-slate-800 text-white font-semibold rounded-xl border border-slate-700/60 hover:border-slate-600 transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
          >
            <ShieldCheck className="w-5 h-5 text-amber-500" />
            Checklist Tool
          </a>
        </motion.div>

        {/* Highlighting metrics on resilience */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
          className="mt-16 sm:mt-24 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto pt-8 border-t border-slate-800/80"
        >
          {[
            { value: "100%", label: "Real, Human Copy" },
            { value: "5 STEPS", label: "Structured Framework" },
            { value: "4 CRITICAL", label: "Mindset Rewires" },
            { value: "ACTIVE", label: "Progress Tracking" },
          ].map((stat, i) => (
            <div key={i} className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/40 backdrop-blur-xs">
              <div className="text-xl sm:text-2xl font-bold text-amber-500 font-mono">{stat.value}</div>
              <div className="text-[10px] sm:text-xs font-semibold uppercase tracking-wider text-slate-400 mt-1">
                {stat.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Decorative Wave at the bottom to transition to light mode seamlessly */}
      <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-slate-50 to-transparent pointer-events-none" />
    </div>
  );
}
