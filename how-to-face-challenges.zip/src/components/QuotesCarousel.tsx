import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Quote, ChevronLeft, ChevronRight, MessageSquare } from "lucide-react";
import { inspirationQuotes } from "../data/challengesData";

export default function QuotesCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const resetTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    timerRef.current = setInterval(() => {
      handleNext();
    }, 4000);
  };

  useEffect(() => {
    resetTimer();
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [currentIndex]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? inspirationQuotes.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === inspirationQuotes.length - 1 ? 0 : prev + 1));
  };

  const selectedQuote = inspirationQuotes[currentIndex];

  return (
    <section className="py-24 bg-slate-900 text-white relative overflow-hidden border-b border-slate-950">
      {/* Decorative atmosphere lights */}
      <div className="absolute top-1/4 right-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header decoration */}
        <div className="flex flex-col items-center mb-8">
          <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center border border-slate-700/60 mb-4 shadow-inner">
            <Quote className="w-5 h-5 text-amber-500 fill-amber-500/20" />
          </div>
          <span className="text-[10px] font-mono tracking-widest uppercase text-amber-500 font-bold">
            Voices of Resilience
          </span>
        </div>

        {/* Carousel Slider Panel */}
        <div className="relative min-h-[280px] sm:min-h-[220px] flex items-center justify-center">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedQuote.id}
              initial={{ opacity: 0, x: 25 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -25 }}
              transition={{ duration: 0.4 }}
              className="text-center px-4 sm:px-12"
            >
              <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-slate-100 font-sans tracking-tight leading-relaxed mb-6">
                &ldquo;{selectedQuote.text}&rdquo;
              </h3>
              
              <div className="font-mono text-xs text-amber-500 font-semibold mb-1 uppercase tracking-wider">
                — {selectedQuote.author}
              </div>
              
              <p className="text-xs text-slate-400 italic max-w-md mx-auto">
                {selectedQuote.context}
              </p>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Navigation Contols */}
        <div className="flex items-center justify-center gap-6 mt-8">
          {/* Back btn */}
          <button
            onClick={handlePrev}
            className="w-10 h-10 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 hover:border-slate-600 transition-all flex items-center justify-center cursor-pointer"
            aria-label="Previous quote"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* Dots Indicators */}
          <div className="flex items-center gap-2">
            {inspirationQuotes.map((q, idx) => (
              <button
                key={q.id}
                onClick={() => setCurrentIndex(idx)}
                className={`transition-all duration-300 ${
                  currentIndex === idx
                    ? "w-8 h-1.5 rounded-full bg-amber-500"
                    : "w-2.5 h-1.5 rounded-full bg-slate-800 hover:bg-slate-700"
                }`}
                aria-label={`Go to slide ${idx + 1}`}
              />
            ))}
          </div>

          {/* Forward btn */}
          <button
            onClick={handleNext}
            className="w-10 h-10 rounded-xl bg-slate-800/80 hover:bg-slate-800 text-slate-400 hover:text-white border border-slate-700/50 hover:border-slate-600 transition-all flex items-center justify-center cursor-pointer"
            aria-label="Next quote"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

      </div>
    </section>
  );
}
