import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sparkles, ArrowRight, CheckCircle, RefreshCw, Layers } from "lucide-react";
import { challengeSteps } from "../data/challengesData";

export default function StepByStep() {
  const [selectedNum, setSelectedNum] = useState(1);

  const selectedStep = challengeSteps.find((s) => s.number === selectedNum) || challengeSteps[0];

  return (
    <section id="steps" className="py-24 bg-slate-900 border-b border-slate-950 text-white relative overflow-hidden">
      {/* Background aesthetics */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-blue-600/5 rounded-full blur-3xl pointer-events-none" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section header */}
        <div className="text-center md:max-w-2xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 bg-amber-500/10 border border-amber-500/30 text-amber-400 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5 font-mono">
            <Layers className="w-3.5 h-3.5 stroke-[2.5]" />
            Methodology
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight mb-4">
            The 5-Step Resolution Paradigm
          </h2>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed">
            In moments of distress, we lose our bearing. Use this structured, cognitive-behavioral pipeline to guide your thoughts back to safety and decisive momentum.
          </p>
        </div>

        {/* Milestone Steps Selector - Beautiful horizontal nodes on desktop / responsive pile on mobile */}
        <div className="relative max-w-4xl mx-auto mb-12">
          {/* Connector Line (hidden on mobile, visible on desktop) */}
          <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-800 -translate-y-1/2 hidden md:block z-0" />
          
          <div className="relative z-10 flex flex-col md:flex-row justify-between gap-4 md:gap-0">
            {challengeSteps.map((step) => {
              const isSelected = step.number === selectedNum;
              const isPast = step.number < selectedNum;
              
              return (
                <button
                  key={step.number}
                  onClick={() => setSelectedNum(step.number)}
                  className="flex items-center gap-4 md:flex-col md:gap-2 text-left md:text-center group focus:outline-none cursor-pointer"
                >
                  <div
                    className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-base transition-all duration-300 border ${
                      isSelected
                        ? "bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20 scale-110"
                        : isPast
                        ? "bg-slate-800 text-amber-500 border-amber-500/45"
                        : "bg-slate-950 text-slate-400 border-slate-800 group-hover:border-slate-700"
                    }`}
                  >
                    {step.number}
                  </div>
                  <div className="md:mt-1">
                    <span
                      className={`block text-sm font-bold transition-colors ${
                        isSelected ? "text-amber-400" : "text-slate-300 group-hover:text-white"
                      }`}
                    >
                      {step.title.split(" & ")[0]}
                    </span>
                    <span className="text-[10px] text-slate-400 md:block hidden lowercase font-medium">
                      {step.brief.slice(0, 20)}...
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Detailed interactive layout pane */}
        <div className="max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={selectedNum}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.35 }}
              className="bg-slate-950/65 backdrop-blur-md rounded-3xl border border-slate-800/80 p-8 sm:p-12 shadow-2xl relative overflow-hidden"
            >
              {/* Massive background number */}
              <div className="absolute right-6 bottom-4 text-9xl font-black text-slate-800/20 select-none pointer-events-none font-mono">
                0{selectedStep.number}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start relative z-10">
                <div className="lg:col-span-7">
                  <span className="text-xs font-bold text-amber-500 font-mono uppercase tracking-widest block mb-2">
                    Phase 0{selectedStep.number} — {selectedStep.brief}
                  </span>
                  
                  <h3 className="text-2xl sm:text-3xl font-extrabold text-white mb-4">
                    {selectedStep.title}
                  </h3>
                  
                  <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
                    {selectedStep.detailed}
                  </p>
                </div>

                <div className="lg:col-span-1 border-t border-slate-800 lg:border-l lg:border-t-0 self-stretch my-2 lg:my-0" />

                <div className="lg:col-span-4 flex flex-col justify-between h-full bg-slate-900 border border-slate-800/50 rounded-2xl p-6">
                  <div>
                    <div className="inline-flex items-center gap-1.5 bg-amber-500/10 text-amber-400 text-[10px] font-bold uppercase tracking-widest px-2.5 py-1 rounded-md mb-4 font-mono">
                      <Sparkles className="w-3.5 h-3.5" />
                      Take action today
                    </div>
                    <h4 className="text-xs font-extrabold uppercase tracking-widest text-slate-400 mb-2">
                      Practical Micro-Assignment
                    </h4>
                    <p className="text-sm font-medium text-slate-200 leading-relaxed italic">
                      &ldquo;{selectedStep.actionableTip}&rdquo;
                    </p>
                  </div>

                  <div className="mt-8 pt-4 border-t border-slate-800 flex justify-between items-center">
                    {selectedNum < 5 ? (
                      <button
                        onClick={() => setSelectedNum((prev) => prev + 1)}
                        className="flex items-center gap-2 text-xs font-bold text-amber-500 hover:text-amber-400 hover:gap-3 transition-all cursor-pointer"
                      >
                        Advance to Step {selectedNum + 1}
                        <ArrowRight className="w-4 h-4" />
                      </button>
                    ) : (
                      <button
                        onClick={() => setSelectedNum(1)}
                        className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-white transition-all cursor-pointer"
                      >
                        <RefreshCw className="w-3.5 h-3.5" />
                        Restart Paradigm Checklist
                      </button>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>

      </div>
    </section>
  );
}
