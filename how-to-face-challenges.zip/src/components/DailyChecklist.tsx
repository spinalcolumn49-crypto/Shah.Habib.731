import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { CheckSquare, Square, RefreshCcw, Plus, Trash2, ShieldCheck, Award, Layers } from "lucide-react";
import { dailyChecklistItems } from "../data/challengesData";
import { ChecklistItem } from "../types";

export default function DailyChecklist() {
  const [items, setItems] = useState<ChecklistItem[]>([]);
  const [completedIds, setCompletedIds] = useState<string[]>([]);
  const [filter, setFilter] = useState<string>("all");
  const [customTask, setCustomTask] = useState("");
  const [customCategory, setCustomCategory] = useState<"mindset" | "action" | "reflection">("action");
  const [customDifficulty, setCustomDifficulty] = useState<"Easy" | "Medium" | "Challenging">("Medium");

  // Load state on mount
  useEffect(() => {
    const savedCompleted = localStorage.getItem("resilience_checklist_completed");
    const savedCustom = localStorage.getItem("resilience_checklist_custom_items");

    if (savedCompleted) {
      try {
        setCompletedIds(JSON.parse(savedCompleted));
      } catch (e) {
        console.error("Local storage parse error: completed list", e);
      }
    }

    let loadedItems = [...dailyChecklistItems];
    if (savedCustom) {
      try {
        const parsedCustom = JSON.parse(savedCustom);
        loadedItems = [...loadedItems, ...parsedCustom];
      } catch (e) {
        console.error("Local storage parse error: custom items", e);
      }
    }
    setItems(loadedItems);
  }, []);

  // Sync state helpers
  const saveCompleted = (ids: string[]) => {
    setCompletedIds(ids);
    localStorage.setItem("resilience_checklist_completed", JSON.stringify(ids));
  };

  const saveCustomItems = (allCurrentItems: ChecklistItem[]) => {
    setItems(allCurrentItems);
    const customOnly = allCurrentItems.filter(
      (item) => !dailyChecklistItems.some((dItem) => dItem.id === item.id)
    );
    localStorage.setItem("resilience_checklist_custom_items", JSON.stringify(customOnly));
  };

  // Toggle completion
  const handleToggle = (id: string) => {
    if (completedIds.includes(id)) {
      saveCompleted(completedIds.filter((item) => item !== id));
    } else {
      saveCompleted([...completedIds, id]);
    }
  };

  // Add custom task
  const handleAddCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTask.trim()) return;

    const newId = `custom-${Date.now()}`;
    const newItem: ChecklistItem = {
      id: newId,
      task: customTask.trim(),
      category: customCategory,
      difficulty: customDifficulty,
    };

    const updated = [...items, newItem];
    saveCustomItems(updated);
    setCustomTask("");
  };

  // Delete custom task
  const handleDeleteCustom = (id: string) => {
    const updated = items.filter((item) => item.id !== id);
    saveCustomItems(updated);
    // Uncheck if checked
    if (completedIds.includes(id)) {
      saveCompleted(completedIds.filter((item) => item !== id));
    }
  };

  // Reset checklist completely
  const handleReset = () => {
    if (window.confirm("Are you sure you want to uncheck all tasks to reset your daily scorecard? Items will remain.")) {
      saveCompleted([]);
    }
  };

  // Get active items count
  const filteredItems = items.filter((item) => {
    if (filter === "all") return true;
    return item.category === filter;
  });

  const totalCount = items.length;
  const completedCount = items.filter((item) => completedIds.includes(item.id)).length;
  const completionPercentage = totalCount > 0 ? Math.round((completedCount / totalCount) * 105) : 0;
  const clampedPercent = Math.min(completionPercentage, 100);

  // Encouraging feedback phrases
  const getFeedbackMessage = () => {
    if (clampedPercent === 0) return "Ready to take ownership of your day?";
    if (clampedPercent < 35) return "Excellent start. Step by step, focus is growing.";
    if (clampedPercent < 70) return "Fantastic trajectory—you are actively building grit!";
    if (clampedPercent < 100) return "Superb momentum, only a few metrics left to complete.";
    return "Outstanding! You have reached full operational resonance today!";
  };

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case "Easy":
        return "bg-slate-100 text-slate-600 border-slate-200";
      case "Medium":
        return "bg-amber-50 text-amber-600 border-amber-200/50";
      case "Challenging":
        return "bg-blue-50 text-blue-600 border-blue-200/50";
      default:
        return "bg-slate-100 text-slate-500";
    }
  };

  return (
    <section id="checklist" className="py-24 bg-white border-b border-slate-100">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-1.5 bg-amber-100/85 border border-amber-200 text-amber-800 text-[11px] font-bold uppercase tracking-wider px-3.5 py-1 rounded-full mb-3.5">
            <CheckSquare className="w-3.5 h-3.5 stroke-[2.5]" />
            Active Workspace
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Daily Resilience Checklist
          </h2>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto">
            Grit is cultivated through modest, systematic habits. Use this scorecard to log key resilience actions, calculate your score, and track custom assignments in real-time.
          </p>
        </div>

        {/* Dashboard Box Card */}
        <div className="bg-slate-50 rounded-2xl border border-slate-200/85 p-6 sm:p-8 shadow-md mb-12">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 mb-6">
            <div>
              <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest block mb-1">
                Scorecard Output
              </span>
              <h3 className="text-xl font-bold text-slate-900">
                {completedCount} of {totalCount} Actions Executed
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {getFeedbackMessage()}
              </p>
            </div>

            <div className="flex items-center gap-4 shrink-0">
              <div className="text-right">
                <span className="text-2xl font-black text-slate-900 font-mono">
                  {clampedPercent}%
                </span>
                <span className="text-[10px] text-slate-400 uppercase block font-semibold tracking-wider">
                  Day Completed
                </span>
              </div>
              <button
                onClick={handleReset}
                disabled={completedCount === 0}
                className="p-3 bg-white border border-slate-200 hover:border-slate-300 disabled:opacity-40 disabled:hover:border-slate-200 text-slate-500 hover:text-slate-700 rounded-xl cursor-pointer transition-colors"
                title="Restart daily checklist"
              >
                <RefreshCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-slate-200 h-3 rounded-full overflow-hidden relative border border-slate-300/40">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${clampedPercent}%` }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="bg-gradient-to-r from-amber-500 via-amber-400 to-amber-600 h-full rounded-full"
            />
          </div>
        </div>

        {/* Filters and Add block */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Checklist Items Column */}
          <div className="lg:col-span-12 space-y-6">
            {/* Nav Filters */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-4 flex-wrap gap-4">
              <div className="flex items-center gap-1.5 flex-wrap">
                {[
                  { value: "all", label: "All Items" },
                  { value: "mindset", label: "Mindset Shifts" },
                  { value: "action", label: "Physical Action" },
                  { value: "reflection", label: "Reflection" },
                ].map((category) => (
                  <button
                    key={category.value}
                    onClick={() => setFilter(category.value)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold tracking-wide transition-all ${
                      filter === category.value
                        ? "bg-slate-900 text-white"
                        : "bg-slate-100 text-slate-500 hover:bg-slate-200 hover:text-slate-800 cursor-pointer"
                    }`}
                  >
                    {category.label}
                  </button>
                ))}
              </div>
              
              <span className="text-[10px] uppercase font-mono tracking-wider font-extrabold text-slate-400">
                Sorted by index
              </span>
            </div>

            {/* Render Items */}
            <div className="space-y-3">
              {filteredItems.length === 0 ? (
                <div className="text-center py-12 border-2 border-dashed border-slate-200 rounded-2xl">
                  <p className="text-slate-400 text-sm">No tasks found matching this criteria.</p>
                </div>
              ) : (
                filteredItems.map((item) => {
                  const isChecked = completedIds.includes(item.id);
                  const isCustom = item.id.startsWith("custom-");

                  return (
                    <motion.div
                      key={item.id}
                      layoutId={item.id}
                      className={`flex items-start gap-4 p-4.5 rounded-xl border transition-all duration-200 ${
                        isChecked
                          ? "bg-slate-50 border-slate-200 opacity-65"
                          : "bg-white border-slate-200 hover:border-slate-300 shadow-xs"
                      }`}
                    >
                      {/* Checkbox Icon */}
                      <button
                        onClick={() => handleToggle(item.id)}
                        className="mt-0.5 text-slate-400 hover:text-amber-500 transition-colors shrink-0 cursor-pointer"
                      >
                        {isChecked ? (
                          <CheckSquare className="w-5.5 h-5.5 text-amber-500 fill-amber-500/10 stroke-[2.25]" />
                        ) : (
                          <Square className="w-5.5 h-5.5 text-slate-400" />
                        )}
                      </button>

                      {/* Content block */}
                      <div className="flex-1 min-w-0">
                        <p
                          onClick={() => handleToggle(item.id)}
                          className={`text-slate-700 text-sm leading-relaxed font-semibold cursor-pointer select-none ${
                            isChecked ? "line-through text-slate-400" : ""
                          }`}
                        >
                          {item.task}
                        </p>
                        
                        <div className="flex items-center gap-2 mt-2">
                          <span className="inline-block px-2 py-0.5 bg-slate-100/90 text-slate-500 rounded text-[10px] font-mono capitalize">
                            {item.category}
                          </span>
                          <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-mono border ${getDifficultyColor(item.difficulty)}`}>
                            {item.difficulty}
                          </span>
                          {isCustom && (
                            <span className="inline-block px-1.5 py-0.5 bg-amber-50 text-amber-600 rounded text-[10px] font-mono border border-amber-100">
                              Custom Input
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Trash tool for custom entries */}
                      {isCustom && (
                        <button
                          onClick={() => handleDeleteCustom(item.id)}
                          className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg shrink-0 transition-colors cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </motion.div>
                  );
                })
              )}
            </div>

            {/* Custom Tasks Adding Drawer Board */}
            <form
              onSubmit={handleAddCustom}
              className="bg-slate-50 border border-slate-200/80 rounded-2xl p-6 shadow-xs mt-6"
            >
              <h4 className="text-sm font-extrabold text-slate-900 uppercase tracking-wider mb-4 flex items-center gap-2">
                <Plus className="w-4 h-4 text-amber-500 stroke-[2.5]" />
                Write Your Own Action Challenge
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                {/* Category Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5 font-mono">
                    Category Paradigm
                  </label>
                  <select
                    value={customCategory}
                    onChange={(e) => setCustomCategory(e.target.value as any)}
                    className="w-full bg-white border border-slate-250 py-2 px-3 rounded-xl text-xs sm:text-sm text-slate-700 outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="mindset">Mindset (Neural reframing)</option>
                    <option value="action">Action (Immediate task)</option>
                    <option value="reflection">Reflection (Contemplation)</option>
                  </select>
                </div>

                {/* Difficulty Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-1.5 font-mono">
                    Required Effort (Grit level)
                  </label>
                  <select
                    value={customDifficulty}
                    onChange={(e) => setCustomDifficulty(e.target.value as any)}
                    className="w-full bg-white border border-slate-250 py-2 px-3 rounded-xl text-xs sm:text-sm text-slate-700 outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="Easy">Easy (Under 5 minutes)</option>
                    <option value="Medium">Medium (Requires focus)</option>
                    <option value="Challenging">Challenging (Pushes comfort)</option>
                  </select>
                </div>
              </div>

              {/* Text Input */}
              <div className="flex gap-3">
                <input
                  type="text"
                  placeholder="Specify a micro-action (e.g., 'Draft three bullet points for my project audit')"
                  value={customTask}
                  onChange={(e) => setCustomTask(e.target.value)}
                  maxLength={120}
                  className="flex-1 bg-white border border-slate-250 py-2.5 px-4 rounded-xl text-xs sm:text-sm text-slate-800 outline-none focus:border-amber-500 font-medium"
                />
                <button
                  type="submit"
                  disabled={!customTask.trim()}
                  className="px-5 py-2.5 bg-slate-900 border border-slate-900 text-white disabled:opacity-40 disabled:hover:bg-slate-900 disabled:hover:text-white hover:bg-slate-800 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-xs flex items-center gap-1.5 shrink-0 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  Add Action
                </button>
              </div>
            </form>
          </div>

        </div>

      </div>
    </section>
  );
}
