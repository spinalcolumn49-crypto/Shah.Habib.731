export interface ChallengeType {
  id: string;
  title: string;
  description: string;
  iconName: string;
  colorClass: string;
  bgClass: string;
  examples: string[];
}

export interface ChallengeStep {
  number: number;
  title: string;
  brief: string;
  detailed: string;
  actionableTip: string;
}

export interface MindsetTip {
  id: string;
  concept: string;
  fixedMindset: string;
  growthMindset: string;
  actionableShift: string;
}

export interface InspirationQuote {
  id: string;
  text: string;
  author: string;
  context: string;
}

export interface PracticalStrategy {
  id: string;
  title: string;
  description: string;
  iconName: string;
  tool: string;
  exercise: string;
}

export interface SuccessStory {
  id: string;
  name: string;
  age: string;
  role: string;
  challenge: string;
  strategyUsed: string;
  result: string;
  quote: string;
  avatarUrl: string;
}

export interface ChecklistItem {
  id: string;
  task: string;
  category: "mindset" | "action" | "reflection";
  difficulty: "Easy" | "Medium" | "Challenging";
}

export interface FaqItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}
